# Native shell composition examples

These original source examples use API 2's `regions-v1` contract in ALTARA **0.1.157 or later**. They change the placement and appearance of existing ALTARA regions, not their features, permissions or data. No assets or code from Discord or Root are included.

| Folder | Composition |
| --- | --- |
| `lateral` | Discord-inspired vertical server rail, navigation beside the conversation, own profile below navigation |
| `header` | Root-inspired horizontal server header, own profile at the upper right, navigation beside the conversation |
| `mirror` | Custom composition with navigation on the right and context on the left; a complete wide-screen override |

From the starter kit's root folder, build one example into a **new** output filename:

```text
node scripts/theme-package.mjs --build examples/community-themes/shell-regions/header/metadata.json examples/community-themes/shell-regions/header/theme.css header-example-1.0.0.altara-theme.json
node scripts/theme-package.mjs --check header-example-1.0.0.altara-theme.json
```

Import the built JSON in **Settings → Appearance → Community themes**, then activate it. To try another example, use its own metadata/CSS pair and a different output filename. Importing does not activate a theme or change your saved widget records.

All four layout properties belong together in each `:root` plan. The seven names must be present and rectangular; track counts must match the matrix. Semantic tracks preserve the host's native sizing decisions. The optional JSON `layout` field is deliberately omitted: it controls the native Home presenter independently of shell placement.

The host keeps native collapse/drawer state, context visibility, voice controls and desktop caption clearance. At 760px or less it uses a host-owned compact arrangement instead of your desktop matrix. Authentication, protected settings, confirmations and other sensitive surfaces can suspend the composition. Older clients keep native placement and the examples' ordinary colors and surfaces. Do not add unconditional fixed-position fallbacks or set host capability/internal geometry variables yourself.

Test real Home, human and bot conversations, channels, calls, zero/loading/populated servers, folders and drag/drop; normal/reduced motion; keyboard navigation; native resizing/collapse; long names; and each breakpoint. The preview contains fictional data and does not prove every live app path. Use **Deactivate** or **Ctrl+Alt+Shift+T** to return to the native appearance without changing messages or widget data.

See `docs/COMMUNITY_THEMES_V1.md` for the complete grammar, limits, protected surfaces and publication workflow. These are editable examples, not production certification or paid theme files.

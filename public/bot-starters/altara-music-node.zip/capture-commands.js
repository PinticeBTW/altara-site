const {AltaraAudioReceiver}=require('./audio-receiver');
// Opt-in example: do not register this against a running bot unless its owner
// enables the new listening/recording grants and supplies a recording directory.
function registerAudioCaptureCommands(bot,{recordingDirectory=null,onFrame=()=>{},createReceiver=options=>new AltaraAudioReceiver(options)}={}){
 const sessions=new Map(),locks=new Map();let stopped=false;
 const serial=(server,fn)=>{const next=(locks.get(server)||Promise.resolve()).catch(()=>{}).then(fn);locks.set(server,next);return next.finally(()=>{if(locks.get(server)===next)locks.delete(server);});};
 const options=lease=>({serverId:lease.server_id,channelId:lease.channel_id,captureId:lease.capture_id});
 const close=async session=>{if(session.closing)return session.closing;session.closing=Promise.resolve().then(async()=>{sessions.delete(session.lease.server_id);await session.receiver.close();});return session.closing;};
 const start=recording=>async ctx=>serial(ctx.serverId,async()=>{
  try{
   if(stopped || (recording&&!recordingDirectory))throw Error('recording_not_configured');
   const existing=sessions.get(ctx.serverId);if(existing){await ctx.getVoiceState({channelId:existing.lease.channel_id});await close(existing);}
   const lease=await ctx.captureVoice({recording});
   const receiver=createReceiver({recordingDirectory:recording?recordingDirectory:null,onFrame,
    heartbeat:value=>bot.heartbeatAudioCapture(options(value)),closeLease:value=>bot.closeAudioCapture(options(value))});
   const session={lease,receiver};
   receiver.on('captureError',()=>bot.emit('error',new Error('audio_capture_failed')));
   receiver.on('closed',()=>{if(sessions.get(ctx.serverId)===session)sessions.delete(ctx.serverId);});
   try{await receiver.connect(lease);}catch(error){await bot.closeAudioCapture(options(lease));throw error;}
   sessions.set(ctx.serverId,session);
   await ctx.reply(recording?'Pedido de gravação aberto por 30 minutos. Cada pessoa tem de autorizar no menu da chamada antes de o seu áudio ser recebido e guardado.':'Pedido de áudio aberto por 30 minutos. Só recebo quem autorizar no menu da chamada. O áudio pode ser processado pelo dono do bot.');
  }catch{if(!ctx.replied)await ctx.reply(recording&&!recordingDirectory?'O dono do bot ainda precisa de configurar a pasta de gravações.':'Não consegui abrir a receção de áudio. Verifica as permissões e a chamada.');}
 });
 bot.command('listen',{description:'Pede autorização para o bot receber áudio'},start(false));
 bot.command('record',{description:'Pede autorização para uma gravação de até 30 minutos'},start(true));
 bot.command('capture-stop',{description:'Termina a receção/gravação de áudio'},ctx=>serial(ctx.serverId,async()=>{
  const session=sessions.get(ctx.serverId);if(!session){await ctx.reply('Não há uma receção de áudio ativa.');return;}
  try{await ctx.getVoiceState({channelId:session.lease.channel_id});await close(session);await ctx.reply('Receção de áudio terminada.');}
  catch{if(!ctx.replied)await ctx.reply('Entra no canal de voz onde está o bot e volta a tentar.');}
 }));
 return {sessions,async stop(){stopped=true;await Promise.allSettled([...locks.values()]);await Promise.allSettled([...sessions.values()].map(close));}};
}
module.exports={registerAudioCaptureCommands};

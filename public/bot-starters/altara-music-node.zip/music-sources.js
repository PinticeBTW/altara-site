const fs = require('node:fs');
const path = require('node:path');
const dns = require('node:dns').promises;
const https = require('node:https');
const {spawn} = require('node:child_process');
const {Transform} = require('node:stream');

const MAX_DURATION = 1800;
const MAX_AUDIO_BYTES = 128 * 1024 * 1024;
const MAX_COLLECTION_TRACKS = 20;
const videoId = /^[A-Za-z0-9_-]{11}$/;
const safeTitle = value => String(value || '').replace(/[\p{Cc}\p{Cf}\\`*_~<>@\[\]]/gu, '').trim().slice(0, 180);
const failure = code => new Error(code);

function parseMusicInput(value) {
  const input = String(value || '').trim();
  if (!input || input.length > 500 || /[\p{Cc}\p{Cf}]/u.test(input)) throw failure('music_input_invalid');
  const uri = /^spotify:(track|album|playlist):([A-Za-z0-9]{22})$/.exec(input);
  if (uri) return {kind: 'spotify', type: uri[1], id: uri[2], url: `https://open.spotify.com/${uri[1]}/${uri[2]}`};
  if (!/^[a-z][a-z\d+.-]*:/i.test(input) && !/^(\/|\\)|\.[a-z]{2,}\//i.test(input)) {
    if (input.length > 200) throw failure('music_input_invalid');
    return {kind: 'search', query: input};
  }
  let url;
  try { url = new URL(input); } catch { throw failure('music_link_unsupported'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.port) throw failure('music_link_unsupported');
  if (url.hostname === 'open.spotify.com') {
    const match = /^\/(?:intl-[a-z]{2}\/)?(track|album|playlist)\/([A-Za-z0-9]{22})\/?$/.exec(url.pathname);
    if (!match) throw failure('music_link_unsupported');
    return {kind: 'spotify', type: match[1], id: match[2], url: `https://open.spotify.com/${match[1]}/${match[2]}`};
  }
  let id;
  if (url.hostname === 'youtu.be') id = /^\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1];
  if (['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com'].includes(url.hostname)) {
    if (url.pathname === '/playlist') {
      const list = url.searchParams.get('list');
      if (!/^[A-Za-z0-9_-]{10,100}$/.test(list || '')) throw failure('music_link_unsupported');
      return {kind: 'youtube-playlist', id: list, url: `https://www.youtube.com/playlist?list=${list}`};
    }
    id = url.pathname === '/watch' ? url.searchParams.get('v') : /^\/(?:shorts|live|embed)\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1];
  }
  if (!videoId.test(id || '')) throw failure('music_link_unsupported');
  // Drop playlist, redirects and all other user-controlled URL parameters.
  return {kind: 'youtube', id, url: `https://www.youtube.com/watch?v=${id}`};
}

function publicIpv4(address) {
  if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(address)) return false;
  const [a, b, c, d] = address.split('.').map(Number);
  if ([a, b, c, d].some(n => n > 255)) return false;
  return !(a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254)
    || (a === 172 && b >= 16 && b <= 31) || (a === 100 && b >= 64 && b <= 127)
    || (a === 192 && (b === 0 || b === 168 || (b === 88 && c === 99)))
    || (a === 198 && [18, 19, 51].includes(b)) || (a === 203 && b === 0));
}

function validateRemoteUrl(value, purpose) {
  let url;
  try { url = new URL(value); } catch { throw failure('music_source_unsafe'); }
  if (String(value).length > 32768 || url.protocol !== 'https:' || url.username || url.password || url.port || url.hash) throw failure('music_source_unsafe');
  const allowed = purpose === 'spotify'
    ? url.hostname === 'open.spotify.com' && /^\/embed\/(track|album|playlist)\/[A-Za-z0-9]{22}$/.test(url.pathname)
    : /^[a-z\d-]+(?:\.[a-z\d-]+)*\.googlevideo\.com$/.test(url.hostname) && url.pathname === '/videoplayback';
  if (!allowed) throw failure('music_source_unsafe');
  return url;
}

function abortable(promise, signal) {
  signal.throwIfAborted();
  let onAbort;
  const cancelled = new Promise((_, reject) => {
    onAbort = () => reject(failure('music_source_cancelled'));
    signal.addEventListener('abort', onAbort, {once: true});
  });
  return Promise.race([promise, cancelled]).finally(() => signal.removeEventListener('abort', onAbort));
}

function createRemoteReader({lookup = dns.lookup, request = https.request} = {}) {
  return async function readRemote(value, {purpose, signal, maxBytes, redirects = 0}) {
    const url = validateRemoteUrl(value, purpose);
    const records = await abortable(lookup(url.hostname, {family: 4, all: true}), signal);
    if (!records.length || records.some(row => !publicIpv4(row.address))) throw failure('music_source_unsafe');
    signal.throwIfAborted();
    const response = await new Promise((resolve, reject) => {
      const req = request(url, {
        signal, agent: false, family: 4, servername: url.hostname, rejectUnauthorized: true,
        // DNS is checked once, then pinned. TLS still validates the original hostname.
        lookup: (_host, options, callback) => callback(null, options.all
          ? [{address: records[0].address, family: 4}] : records[0].address, ...(options.all ? [] : [4])),
        headers: {'user-agent': 'Mozilla/5.0 ALTARA-Music/0.1', 'accept-encoding': 'identity'},
      }, resolve);
      const timer = setTimeout(() => req.destroy(failure('music_source_timeout')), 12000);
      req.once('response', () => clearTimeout(timer));
      req.once('error', reject);
      req.once('close', () => clearTimeout(timer));
      req.end();
    });
    if ([301, 302, 303, 307, 308].includes(response.statusCode)) {
      response.destroy();
      if (redirects >= 3 || !response.headers.location) throw failure('music_source_unavailable');
      // Every redirect must stay in the source allowlist and pass a fresh DNS check.
      return readRemote(new URL(response.headers.location, url).href, {purpose, signal, maxBytes, redirects: redirects + 1});
    }
    if (response.statusCode !== 200) {
      response.destroy();
      throw failure(response.statusCode === 403 || response.statusCode === 429 ? 'music_source_blocked' : 'music_source_unavailable');
    }
    if (Number(response.headers['content-length']) > maxBytes) {
      response.destroy(); throw failure('music_source_too_large');
    }
    let bytes = 0;
    const bounded = new Transform({transform(chunk, _encoding, callback) {
      bytes += chunk.length;
      callback(bytes > maxBytes ? failure('music_source_too_large') : null, bytes > maxBytes ? undefined : chunk);
    }});
    response.once('error', error => bounded.destroy(error));
    response.once('aborted', () => bounded.destroy(failure('music_source_unavailable')));
    bounded.once('close', () => response.destroy());
    return response.pipe(bounded);
  };
}

function extractorPath() {
  if (process.env.ALTARA_YTDLP_PATH) return process.env.ALTARA_YTDLP_PATH;
  const local = path.join(__dirname, '.tools', process.platform === 'win32' ? 'Scripts' : 'bin', process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp');
  return fs.existsSync(local) ? local : 'yt-dlp';
}

function runYtDlp(target, {signal, binary = extractorPath(), spawnProcess = spawn, collection = false, limit = MAX_COLLECTION_TRACKS} = {}) {
  return new Promise((resolve, reject) => {
    signal.throwIfAborted();
    const env = {};
    for (const key of ['PATH', 'Path', 'SystemRoot', 'SYSTEMROOT', 'TEMP', 'TMP']) if (process.env[key]) env[key] = process.env[key];
    const count = Math.max(1, Math.min(MAX_COLLECTION_TRACKS, Number.isInteger(limit) ? limit : MAX_COLLECTION_TRACKS));
    const child = spawnProcess(binary, [
      '--ignore-config', '--no-plugin-dirs', '--no-cache-dir', '--no-remote-components', '--skip-download', '--no-warnings',
      '--no-geo-bypass', '--proxy', '', '--socket-timeout', '8', '--retries', '0', '--extractor-retries', '0',
      '--no-js-runtimes', '--js-runtimes', `node:${process.execPath}`, '--use-extractors', collection ? 'youtube:tab,youtube' : 'youtube,youtube:search',
      ...(collection ? ['--yes-playlist', '--flat-playlist', '--playlist-end', String(count), '--dump-single-json']
        : ['--no-playlist', '--print', '%(.{id,title,duration,url,protocol,acodec,vcodec})j', '-f', 'bestaudio[protocol=https]']), '--', target,
    ], {shell: false, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'], env});
    let output = '', diagnostics = '', problem = null;
    const abort = () => { problem ||= failure('music_source_cancelled'); child.kill(); };
    const timer = setTimeout(() => { problem = failure('music_source_timeout'); child.kill(); }, 15000);
    signal.addEventListener('abort', abort, {once: true});
    child.stdout.on('data', chunk => {
      if (problem) return;
      output += chunk.toString();
      if (Buffer.byteLength(output) > (collection ? 524288 : 65536)) { problem = failure('music_source_unavailable'); child.kill(); }
    });
    // Never return extractor diagnostics: they can contain signed media URLs.
    child.stderr.on('data', chunk => { diagnostics = (diagnostics + chunk.toString()).slice(-8192); });
    const cleanup = () => { clearTimeout(timer); signal.removeEventListener('abort', abort); };
    child.once('error', () => { cleanup(); reject(failure('music_extractor_missing')); });
    child.once('close', code => {
      cleanup();
      if (problem) return reject(problem);
      if (code !== 0) return reject(failure(/confirm.*not a bot|sign in|HTTP Error: (403|429)/i.test(diagnostics) ? 'music_source_blocked' : 'music_source_unavailable'));
      try { resolve(JSON.parse(output)); } catch { reject(failure('music_source_unavailable')); }
    });
    if (signal.aborted) abort();
  });
}

function spotifyEntity(html, type, id) {
  const block = /<script\b(?=[^>]*\bid="__NEXT_DATA__")[^>]*>([\s\S]*?)<\/script>/i.exec(html);
  let entity;
  try { entity = JSON.parse(block?.[1]).props.pageProps.state.data.entity; } catch { throw failure('music_spotify_unavailable'); }
  if (!entity || entity.type !== type || entity.uri !== `spotify:${type}:${id}` || !safeTitle(entity.name || entity.title)) throw failure('music_spotify_unavailable');
  return entity;
}

function spotifyMetadata(html, id) {
  const entity = spotifyEntity(html, 'track', id);
  if (!Number.isFinite(entity.duration) || entity.duration <= 0 || entity.duration > MAX_DURATION * 1000) throw failure('music_spotify_unavailable');
  const artists = Array.isArray(entity.artists) ? entity.artists.map(a => safeTitle(a.name)).filter(Boolean).slice(0, 3) : [];
  if (!artists.length) throw failure('music_spotify_unavailable');
  return {title: safeTitle(entity.name || entity.title), artists: artists.join(', '), duration: Number(entity.duration) / 1000};
}

function spotifyCollectionMetadata(html, input, limit = MAX_COLLECTION_TRACKS) {
  const entity = spotifyEntity(html, input.type, input.id);
  if (!Array.isArray(entity.trackList) || !entity.trackList.length || entity.trackList.length > 1000) throw failure('music_spotify_unavailable');
  const tracks = entity.trackList.slice(0, limit).map(row => {
    const id = /^spotify:track:([A-Za-z0-9]{22})$/.exec(row?.uri || '')?.[1];
    if (!id || !safeTitle(row.title) || !safeTitle(row.subtitle) || row.isPlayable === false
      || !Number.isFinite(row.duration) || row.duration <= 0 || row.duration > MAX_DURATION * 1000) throw failure('music_spotify_unavailable');
    return {id, title: safeTitle(row.title), artists: safeTitle(row.subtitle), duration: row.duration / 1000};
  });
  return {title: safeTitle(entity.name || entity.title), tracks, truncated: entity.trackList.length > tracks.length};
}

function createMusicSources({extract = runYtDlp, readRemote = createRemoteReader()} = {}) {
  // Signed CDN URLs stay private, expire quickly and are refreshed for queued tracks.
  const streams = new WeakMap(), recent = new Map();
  const deferred = new WeakMap();
  const readSpotify = async (input, signal) => {
    const body = await readRemote(`https://open.spotify.com/embed/${input.type || 'track'}/${input.id}`, {purpose: 'spotify', signal, maxBytes: 2 * 1024 * 1024});
    const parts = []; let bytes = 0;
    try {for await (const chunk of body) {const data=Buffer.from(chunk);bytes += data.length;if (bytes > 2 * 1024 * 1024) throw failure('music_source_too_large');parts.push(data);}}
    finally {body.destroy();}
    return Buffer.concat(parts).toString('utf8');
  };
  const copyTrack=track=>{const copy={...track};streams.set(copy,streams.get(track));return copy;};
  const resolveYoutube = async (input, signal, {fresh=false}={}) => {
    signal.throwIfAborted();
    const cached=input.kind==='youtube'?recent.get(input.id):null;
    if(!fresh && cached && cached.expires>Date.now())return copyTrack(cached.track);
    if(cached)recent.delete(input.id);
    const info = await extract(input.kind === 'search' ? `ytsearch1:${input.query}` : input.url, {signal});
    if (!videoId.test(info.id || '') || (input.id && info.id !== input.id)
      || !safeTitle(info.title) || !Number.isFinite(info.duration) || info.duration <= 0 || info.duration > MAX_DURATION
      || info.protocol !== 'https' || !info.acodec || info.acodec === 'none' || info.vcodec !== 'none') throw failure('music_track_unavailable');
    validateRemoteUrl(info.url, 'youtube');
    const track = {kind: 'youtube', id: info.id, title: safeTitle(info.title), duration: info.duration, url: `https://www.youtube.com/watch?v=${info.id}`};
    streams.set(track, {url: info.url, expires: Date.now() + 60000});
    recent.delete(track.id);recent.set(track.id,{track,expires:Date.now()+60000});
    if(recent.size>32)recent.delete(recent.keys().next().value);
    return copyTrack(track);
  };
  const matchSpotify = async (metadata, input, signal) => {
      const track = await resolveYoutube({kind: 'search', query: `${metadata.artists} ${metadata.title}`}, signal);
      if (!Number.isFinite(metadata.duration) || Math.abs(track.duration - metadata.duration) > Math.max(15, metadata.duration * 0.15)) throw failure('music_spotify_match_failed');
      track.requestedUrl = input.url;
      track.requestedTitle = safeTitle(`${metadata.artists} — ${metadata.title}`);
      return track;
  };
  const lazy = (input, metadata) => {
    const track = {kind: 'source', id: input.id, title: metadata?.title || input.title, url: input.url};
    deferred.set(track, {input, metadata});return track;
  };
  const prepareTrack = async (track, signal) => {
    if (track.kind !== 'source') return track;
    const item = deferred.get(track);
    if (!item) throw failure('music_source_unsafe');
    return item.metadata ? matchSpotify(item.metadata, item.input, signal) : resolveYoutube(item.input, signal);
  };
  const api = {
    async resolve(value, signal) {
      const input = parseMusicInput(value);
      if (input.kind === 'youtube-playlist' || (input.kind === 'spotify' && input.type !== 'track')) throw failure('music_collection_requires_batch');
      if (input.kind !== 'spotify') return resolveYoutube(input, signal);
      const matched=await matchSpotify(spotifyMetadata(await readSpotify(input, signal), input.id), input, signal);
      return matched;
    },
    async resolveBatch(value, signal, {limit = MAX_COLLECTION_TRACKS} = {}) {
      const count = Math.max(1, Math.min(MAX_COLLECTION_TRACKS, Number.isInteger(limit) ? limit : MAX_COLLECTION_TRACKS));
      const input = parseMusicInput(value);
      let tracks, title, truncated;
      if (input.kind === 'youtube-playlist') {
        const list = await extract(input.url, {signal, collection: true, limit: count});
        if (list?._type !== 'playlist' || list.id !== input.id || !Array.isArray(list.entries) || !list.entries.length || list.entries.length > count) throw failure('music_track_unavailable');
        tracks = list.entries.map(row => {
          if (!videoId.test(row?.id || '') || !safeTitle(row.title) || row.is_live === true
            || (row.duration != null && (!Number.isFinite(row.duration) || row.duration <= 0 || row.duration > MAX_DURATION))) throw failure('music_track_unavailable');
          const url = `https://www.youtube.com/watch?v=${row.id}`;
          return lazy({kind: 'youtube', id: row.id, title: safeTitle(row.title), url});
        });
        title = safeTitle(list.title) || 'Playlist YouTube';
        truncated = Number.isFinite(list.playlist_count) ? list.playlist_count > tracks.length : tracks.length === count;
      } else if (input.kind === 'spotify' && input.type !== 'track') {
        const metadata = spotifyCollectionMetadata(await readSpotify(input, signal), input, count);
        tracks = metadata.tracks.map(row => lazy({kind: 'spotify', type: 'track', id: row.id, url: `https://open.spotify.com/track/${row.id}`}, row));
        title = metadata.title;truncated = metadata.truncated;
      } else return {tracks: [await api.resolve(value, signal)], title: null, truncated: false};
      // Start after resolving the first entry; later entries are resolved only
      // when their turn arrives. This avoids 20 lookups before any audio plays.
      tracks[0] = await prepareTrack(tracks[0], signal);
      return {tracks, title, truncated, url: input.url};
    },
    prepareTrack,
    async openStream(track, signal) {
      const url = parseMusicInput(track.url);
      if (url.kind !== 'youtube' || url.id !== track.id) throw failure('music_source_unsafe');
      let stream = streams.get(track);
      if (!stream || stream.expires <= Date.now()) {
        const refreshed = await resolveYoutube(url, signal, {fresh:true});
        stream = streams.get(refreshed);
      }
      // No cookies, bot tokens or authorization headers are sent to the media host.
      const deadline = AbortSignal.any([signal, AbortSignal.timeout(35 * 60 * 1000)]);
      return readRemote(stream.url, {purpose: 'youtube', signal: deadline, maxBytes: MAX_AUDIO_BYTES});
    },
  };return api;
}

module.exports = {createMusicSources, parseMusicInput, publicIpv4, validateRemoteUrl, createRemoteReader, runYtDlp, spotifyMetadata, spotifyCollectionMetadata, safeTitle};

try {
  require("dotenv/config");
} catch (_) {
  // `npm install` enables .env loading. Environment variables still work without dotenv.
}

const fs=require('node:fs'),path=require('node:path');
const {AltaraClient}=fs.existsSync(path.join(__dirname,'altara-client.js'))
  ? require('./altara-client') : require('../altara-ping-bot-node/altara-client');
const {registerMusicCommands}=require('./commands');
const bot=new AltaraClient({token:process.env.ALTARA_BOT_TOKEN,functionsUrl:process.env.ALTARA_FUNCTIONS_URL});
const music=registerMusicCommands(bot);
// Receiving is a separate, explicit operator opt-in. Ordinary music publishing
// stays unsubscribed and never requests participants' microphone audio.
const capture=process.env.ALTARA_BOT_AUDIO_CAPTURE_EXAMPLE==='1'
  ? require('./capture-commands').registerAudioCaptureCommands(bot,{recordingDirectory:process.env.ALTARA_RECORDING_DIRECTORY||null}) : null;
bot.on('error',()=>console.error('[altara-music] An operation failed; check voice permissions, the music source and installed tools.'));
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{
  void Promise.allSettled([music.stop(),capture?.stop()]).then(results=>{
    if(results.some(result=>result.status==='rejected'))console.error('[altara-music] Voice cleanup failed.');
  }).finally(async()=>{
    bot.stop();await require('@livekit/rtc-node').dispose();
  });
});
bot.login();

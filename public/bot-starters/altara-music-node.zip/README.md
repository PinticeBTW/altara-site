# ALTARA music bot

Real audio publication with slash playback controls. The player uses the official LiveKit Node RTC SDK and FFmpeg to publish a test melody, local files or YouTube audio. Optional yt-dlp integration accepts YouTube links/playlists, song searches and public Spotify tracks/albums/playlists (matched to audio on YouTube). Read ALTARA_BOTS_MUSIC.md in the download, or docs/ALTARA_BOTS_MUSIC.md in the repository, for requirements, limits and activation status.

## Start

Use Node.js 22.12+ and a dedicated test bot. In the extracted starter folder:

```powershell
npm ci
Copy-Item .env.example .env
```

On macOS/Linux use `cp .env.example .env`. Fill in the private token and Functions URL supplied by ALTARA. Keep .env private. Optionally put local music files into music or set ALTARA_MUSIC_DIRECTORY. Then run `npm start`.

Approve the slash, messages, embeds and voice permissions listed in the guide. Enter a public voice channel and run `/play` in a text channel. Controls: `/pause`, `/resume`, `/skip`, `/queue`, `/volume nivel:35`, `/stop`. Ctrl+C closes the bot's voice connections.

The bot synchronizes its command registry at startup. Do not run this standalone starter with the token of another running bot. The repository ping starter has an optional integration that preserves its existing commands.

## Links and song searches

Install Python 3.10+ and the optional source tools in this starter folder. On Windows:

```powershell
py -3 -m venv .tools
.\.tools\Scripts\python.exe -m pip install -r requirements-sources.txt
```

On macOS/Linux:

```sh
python3 -m venv .tools
.tools/bin/python -m pip install -r requirements-sources.txt
```

The bot finds this isolated installation automatically. Alternatively install a compatible yt-dlp and set ALTARA_YTDLP_PATH to its executable. Use Node.js 22.12+ for the YouTube JavaScript runtime. No browser cookies or Spotify credentials are required by this example.

Restart the bot, join a voice channel and enter `/play <link>` with a YouTube or Spotify link, or `/play artist song name`. There is no need to type `faixa:`; the existing named-option form remains compatible. `/play` without a value keeps playing the original test melody. Local library IDs and exact filenames still work. Spotify requests show both the requested track and the actual YouTube source; the audio is not streamed from Spotify. Explicit YouTube playlist URLs and public Spotify album/playlist links add the first 20 tracks, within the queue limit. Later tracks resolve when played. Live streams, private collections, Spotify short share links and tracks longer than 30 minutes are not supported.

External requests receive an immediate preparing message which is edited with the result. `/stop` cancels pending lookups as well as the queue; pause/stop do not wait for a source lookup. The player preserves pause/volume/queue and an approximate playback position after an authorized voice recovery. Recovery requires the updated backend action; failures stop safely and request a fresh `/play`. See the guide for verification and limits.

These commands belong to this starter. Each bot developer chooses their own command names and options using the public SDK.

Source availability depends on the external service. Access blocks, removed videos or source changes produce a chat error. If yt-dlp needs an update, review its upstream release and update requirements-sources.txt in your private bot before reinstalling. The reference release tested here is 2026.8.19. The source guide describes security and verification.

## Optional listening and recording

The new capture backend and participant consent UI must be active first. Set
`ALTARA_BOT_AUDIO_CAPTURE_EXAMPLE=1` in your private `.env` to enable `/listen`,
`/record` and `/capture-stop`, then restart. Approve Listen to Voice; Record Voice
is additionally needed for recording. Set `ALTARA_RECORDING_DIRECTORY` to a
local directory you choose to enable `/record`; leaving it empty disables
recording. This option is off by default and does not change the music player.

Each person must explicitly authorize their own microphone in the call menu.
The bot receives only those microphone clones in a separate capture room;
newcomers receive no inherited consent. Mute/deafen, revoke and leaving stop the
mirror. Up to eight people and 30 minutes are supported. `/listen` exposes PCM
to code without writing files; `/record` writes separate random-named WAV files
into the operator's directory. Received audio can be retained by a developer,
so participants must trust the bot owner. Review the guide for privacy,
revocation/renewal fences, storage limits and pending live verification.

Custom bots can import `registerAudioCaptureCommands` from `capture-commands.js`
or use `AltaraAudioReceiver` directly. The SDK methods are `ctx.captureVoice`,
`bot.heartbeatAudioCapture` and `bot.closeAudioCapture`. Shutdown must call the
capture controller's `stop()` as well as the music controller's `stop()`.

The old music-bot.js is retained as a historical connection-only proof of concept; index.js, commands.js and audio-player.js implement this starter. That old CLI does not supply a claimed slash event and cannot replace this player on the current backend.

## Dependencies and limits

LiveKit RTC Node is Apache-2.0; ffmpeg-static is GPL-3.0-or-later and downloads FFmpeg when dependencies are installed. yt-dlp's Python wheel is Unlicense; its dependencies have their own notices. Keep notices and follow the licenses when redistributing binaries. ALTARA_FFMPEG_PATH can select your own FFmpeg. The archive contains source only, no tokens, operator files, .tools environment or media binaries. Local WAV/MP3/OGG/FLAC/M4A files are supported. Remote inputs are restricted to supported YouTube/Spotify links and YouTube searches. Use music you are allowed to play.

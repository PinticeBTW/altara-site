const {EventEmitter}=require('node:events');
const fs=require('node:fs');
const path=require('node:path');
const {spawn}=require('node:child_process');
const {pipeline}=require('node:stream/promises');
const SAMPLE_RATE=48000,CHANNELS=2,FRAME_SAMPLES=960,FRAME_BYTES=FRAME_SAMPLES*CHANNELS*2;

function musicCatalogue(directory) {
 const tracks=new Map([['teste',{id:'teste',title:'Melodia de teste ALTARA',kind:'test'}]]);
 if (!directory || !fs.existsSync(directory)) return tracks;
 const root=fs.realpathSync(directory);
 for (const name of fs.readdirSync(root).sort()) {
  if (tracks.size>=25) break;
  if (!/\.(wav|mp3|ogg|flac|m4a)$/i.test(name)) continue;
  const filename=fs.realpathSync(path.join(root,name));
  const relative=path.relative(root,filename);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative) || !fs.statSync(filename).isFile()) continue;
  const id=String(tracks.size),title=name.replace(/[\p{Cc}\p{Cf}`*_~<>@]/gu,'').slice(0,90);
  tracks.set(id,{id,title,kind:'file',filename,root});
 }
 return tracks;
}

async function* decodeFrames(track,signal,ffmpegPath,{openStream=null}={}) {
 if (track.kind==='test') {
  // A quiet original melody, with short fades instead of clicks at note edges.
  const notes=[261.63,329.63,392,523.25,392,329.63,293.66,349.23];
  for (let frame=Math.floor(Math.max(0,Number(track.offsetSeconds)||0)*50);frame<1500 && !signal.aborted;frame++) {
   const pcm=new Int16Array(FRAME_SAMPLES*CHANNELS);
   for(let i=0;i<FRAME_SAMPLES;i++) {
    const n=frame*FRAME_SAMPLES+i,t=n/SAMPLE_RATE,noteTime=t%0.4;
    const fade=Math.min(1,noteTime/0.02,(0.4-noteTime)/0.025);
    const value=Math.round(5000*fade*Math.sin(2*Math.PI*notes[Math.floor(t/0.4)%notes.length]*t));
    pcm[i*2]=value;pcm[i*2+1]=value;
   }
   yield pcm;
  }
  return;
 }
 let input=null,real;
 if(track.kind==='youtube') {
  if(!openStream)throw new Error('music_source_unavailable');
  input=await openStream(track,signal);
 } else {
  // Recheck operator catalogue files; a chat value can never become a file path.
  if(track.kind!=='file')throw new Error('music_track_unknown');
  real=fs.realpathSync(track.filename);
  const relative=path.relative(track.root,real);
  if(relative.startsWith('..') || path.isAbsolute(relative) || !fs.statSync(real).isFile()) throw new Error('music_file_unavailable');
 }
 const safeEnv={};
 for(const key of ['PATH','Path','SystemRoot','SYSTEMROOT','TEMP','TMP']) if(process.env[key])safeEnv[key]=process.env[key];
 // Remote audio is fetched by the pinned HTTPS reader, then piped to FFmpeg.
 // The decoder itself cannot open network URLs or local files from that stream.
 const decoder=spawn(ffmpegPath,['-hide_banner','-loglevel','error','-nostdin','-protocol_whitelist',input?'pipe':'file,pipe',
  '-i',input?'pipe:0':real,...(track.offsetSeconds>0?['-ss',String(Math.min(1800,track.offsetSeconds))]:[]),'-vn','-t','1800','-f','s16le','-acodec','pcm_s16le','-ar',String(SAMPLE_RATE),'-ac',String(CHANNELS),'pipe:1'],
  {shell:false,windowsHide:true,stdio:[input?'pipe':'ignore','pipe','pipe'],env:safeEnv});
 let decoderError=null,inputError=null,ended=false;
 const completion=new Promise(resolve=>{
  decoder.once('error',error=>{decoderError=error;ended=true;resolve(-1);});
  decoder.once('close',code=>{ended=true;resolve(code);});
 });
 const inputTask=input?pipeline(input,decoder.stdin).catch(error=>{inputError=error;decoder.kill();}):Promise.resolve();
 decoder.stderr.resume(); // Decoder diagnostics may contain private paths.
 const abort=()=>{input?.destroy();decoder.kill();decoder.stdout.destroy();};
 signal.addEventListener('abort',abort,{once:true});
 if(signal.aborted)abort();
 let pending=Buffer.alloc(0);
 try {
  for await(const chunk of decoder.stdout) {
   if(signal.aborted)break;
   pending=Buffer.concat([pending,chunk]);
   while(pending.length>=FRAME_BYTES) {
    const pcm=new Int16Array(FRAME_SAMPLES*CHANNELS);
    for(let i=0;i<pcm.length;i++)pcm[i]=pending.readInt16LE(i*2);
    pending=pending.subarray(FRAME_BYTES);
    yield pcm;
   }
  }
  if(!signal.aborted && (await completion)!==0)throw new Error(/^music_/.test(inputError?.message || '')?inputError.message:'music_decode_failed');
  if(decoderError && !signal.aborted)throw new Error('music_decoder_unavailable');
  if(!signal.aborted && pending.length) {
   const pcm=new Int16Array(FRAME_SAMPLES*CHANNELS);
   for(let i=0;i<Math.floor(pending.length/2);i++)pcm[i]=pending.readInt16LE(i*2);
   yield pcm;
  }
 } finally {
  signal.removeEventListener('abort',abort);
  if(!ended)abort();
  await completion;
  input?.destroy();await inputTask;
 }
}

class AltaraVoicePlayer extends EventEmitter {
 constructor({rtc=null,ffmpegPath=null,frames=decodeFrames,openStream=null,prepareTrack=async track=>track}={}) {
  super();this.rtc=rtc;this.ffmpegPath=ffmpegPath;this.frames=(...args)=>frames(...args,{openStream});
  this.queue=[];this.current=null;this.paused=false;this.volume=0.35;
  this.closed=false;this.task=null;this.wake=null;this.abort=null;this.prepareTrack=prepareTrack;this.transportSuspended=false;
 }
 async connect(voice) {
  if(this.closed || this.room)throw new Error('voice_player_already_used');
  const expected=`server-voice-v2:${voice.server_id}:${voice.channel_id}`;
  if(voice.media_protocol!=='server_voice_media_v1' || voice.room_name!==expected || !voice.connection_id
    || !voice.can_publish_audio || voice.can_subscribe_audio!==false || !voice.token || !/^wss:\/\//.test(voice.livekit_url))throw new Error('invalid_voice_connection');
  this.rtc ||= require('@livekit/rtc-node');
  this.ffmpegPath ||= process.env.ALTARA_FFMPEG_PATH || require('ffmpeg-static');
  this.voice=voice;this.room=new this.rtc.Room();
  try {
   await this.room.connect(voice.livekit_url,voice.token,{autoSubscribe:false,dynacast:false});
   // Keep the short-lived token out of the player after connect.
   this.voice={...voice,token:undefined,livekit_url:undefined};
   this.source=new this.rtc.AudioSource(SAMPLE_RATE,CHANNELS,100);
   this.track=this.rtc.LocalAudioTrack.createAudioTrack('ALTARA music',this.source);
   const options=new this.rtc.TrackPublishOptions();options.source=this.rtc.TrackSource.SOURCE_MICROPHONE;
   this.publication=await this.room.localParticipant.publishTrack(this.track,options);
   this.onDisconnect=()=>{this.emit('disconnected',this.recoveryState());void this.close().catch(()=>this.emit('playbackError',new Error('voice_cleanup_failed')));};
   this.onReconnecting=()=>{this.transportSuspended=true;this.source?.clearQueue();this.emit('reconnecting');};
   this.onReconnected=()=>{this.emit('reconnected');};
   this.room.on(this.rtc.RoomEvent.Disconnected,this.onDisconnect);
   if(this.rtc.RoomEvent.Reconnecting)this.room.on(this.rtc.RoomEvent.Reconnecting,this.onReconnecting);
   if(this.rtc.RoomEvent.Reconnected)this.room.on(this.rtc.RoomEvent.Reconnected,this.onReconnected);
  } catch(error) {try{await this.close();}catch{}throw error;}
  return this;
 }
 enqueue(track) {
  if(this.closed || !this.source)throw new Error('voice_player_closed');
  if(this.queue.length>=20)throw new Error('music_queue_full');
  this.queue.push(track);this.ensurePump();return this.queue.length;
 }
 ensurePump() {
  if(this.task || this.closed)return;
  this.task=this.pump().catch(error=>{this.emit('playbackError',error);})
   .finally(()=>{this.task=null;if(this.queue.length && !this.closed)this.ensurePump();else this.emit('idle');});
 }
 async pump() {
  while(this.queue.length && !this.closed) {
   this.current=this.queue.shift();this.abort=new AbortController();this.capturedFrames=0;
   const signal=this.abort.signal;
   try {
    this.current=await this.prepareTrack(this.current,AbortSignal.any([signal,AbortSignal.timeout(25000)]));
    if(signal.aborted || this.closed)break;
    this.emit('track',this.current);
    for await(const pcm of this.frames(this.current,signal,this.ffmpegPath)) {
     while((this.paused || this.transportSuspended) && !signal.aborted && !this.closed)await new Promise(resolve=>{this.wake=resolve;});
     if(signal.aborted || this.closed)break;
     const scaled=new Int16Array(pcm.length);
     for(let i=0;i<pcm.length;i++)scaled[i]=Math.max(-32768,Math.min(32767,Math.round(pcm[i]*this.volume)));
     await this.source.captureFrame(new this.rtc.AudioFrame(scaled,SAMPLE_RATE,CHANNELS,FRAME_SAMPLES));
     this.capturedFrames++;
     if(this.capturedFrames===1)this.emit('playing',this.current);
    }
    if(!signal.aborted && !this.closed)await this.source.waitForPlayout();
   } catch(error) {if(!signal.aborted && !this.closed)this.emit('playbackError',error);}
   finally {this.current=null;this.abort=null;}
  }
 }
 pause() {if(this.closed)throw new Error('voice_player_closed');this.paused=true;this.source?.clearQueue();}
 resume() {this.paused=false;this.wake?.();this.wake=null;}
 transportReady() {this.transportSuspended=false;this.wake?.();this.wake=null;}
 recoveryState() {
  const current=this.current?(this.current.kind==='source'?this.current:{...this.current,offsetSeconds:Math.min(1800,(Number(this.current.offsetSeconds)||0)+(this.capturedFrames||0)/50)}):null;
  return {tracks:[...(current?[current]:[]),...this.queue],paused:this.paused,volume:Math.round(this.volume*100)};
 }
 skip() {this.abort?.abort();this.source?.clearQueue();this.resume();}
 setVolume(percent) {
  const n=Number(percent);if(!Number.isInteger(n)||n<0||n>100)throw new Error('invalid_music_volume');
  this.volume=n/100;
 }
 status() {return {current:this.current?.title || null,queue:this.queue.map(t=>t.title),paused:this.paused,volume:Math.round(this.volume*100)};}
 async close() {
  if(this.closing)return this.closing;
  this.closed=true;this.queue=[];this.abort?.abort();this.resume();
  this.closing=(async()=>{
   if(this.room && this.onDisconnect)this.room.off(this.rtc.RoomEvent.Disconnected,this.onDisconnect);
   if(this.room && this.rtc.RoomEvent.Reconnecting)this.room.off(this.rtc.RoomEvent.Reconnecting,this.onReconnecting);
   if(this.room && this.rtc.RoomEvent.Reconnected)this.room.off(this.rtc.RoomEvent.Reconnected,this.onReconnected);
   const errors=[];
   for(const cleanup of [()=>this.source?.clearQueue(),()=>this.track?.close(false),
    ()=>this.source?.close(),()=>this.room?.disconnect(),()=>this.task]) {
    try{await cleanup();}catch(error){errors.push(error);}
   }
   this.emit('closed');
   if(errors.length)throw new Error('voice_cleanup_failed');
  })();
  return this.closing;
 }
}
module.exports={AltaraVoicePlayer,musicCatalogue,decodeFrames,SAMPLE_RATE,CHANNELS,FRAME_SAMPLES};

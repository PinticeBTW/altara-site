const path=require('node:path');
const {performance}=require('node:perf_hooks');
const {AltaraVoicePlayer,musicCatalogue}=require('./audio-player');
const {createMusicSources}=require('./music-sources');

function registerMusicCommands(bot,{directory=process.env.ALTARA_MUSIC_DIRECTORY || path.join(__dirname,'music'),
 sources=createMusicSources(),createPlayer=()=>new AltaraVoicePlayer({openStream:sources.openStream,prepareTrack:sources.prepareTrack}),heartbeatMs=20000,idleMs=60000}={}) {
 const catalogue=musicCatalogue(directory),sessions=new Map(),locks=new Map(),lookups=new Map(),pending=new Map(),tasks=new Set(),timings=new WeakMap();
 const shutdown=new AbortController();
 let stopped=false;
 const serial=(server,fn)=>{
  const previous=locks.get(server)||Promise.resolve();
  const next=previous.catch(()=>{}).then(fn);locks.set(server,next);
  return next.finally(()=>{if(locks.get(server)===next)locks.delete(server);});
 };
 const sessionOptions=s=>({serverId:s.voice.server_id,channelId:s.voice.channel_id,connectionId:s.voice.connection_id});
 const pendingFor=server=>[...(pending.get(server)||[])];
 const cancelPending=server=>{for(const job of pendingFor(server))job.cancel.abort();};
 const cancellable=async(promise,signal)=>{
  signal.throwIfAborted();let abort;
  const cancelled=new Promise((_,reject)=>{abort=()=>reject(new Error('music_source_cancelled'));signal.addEventListener('abort',abort,{once:true});});
  try{return await Promise.race([promise,cancelled]);}finally{signal.removeEventListener('abort',abort);}
 };
 const clearIdle=s=>{clearTimeout(s.idleTimer);s.idleEpoch=(s.idleEpoch||0)+1;};
 const close=async s=>{
  if(s.closing)return s.closing;
  clearTimeout(s.timer);clearIdle(s);
  if(sessions.get(s.voice.server_id)===s)sessions.delete(s.voice.server_id);
  // Set the closing fence before a player can synchronously emit "closed".
  s.closing=Promise.resolve().then(async()=>{try{await s.player.close();}finally{await bot.closeVoiceConnection(sessionOptions(s));}});
  return s.closing;
 };
 const watch=(s,delay=heartbeatMs)=>{
  clearTimeout(s.timer);
  if(s.heartbeatRunning){s.statusPending=true;return;}
  s.timer=setTimeout(async()=>{
   if(s.closing || s.recovering || stopped)return;
   s.heartbeatRunning=true;
   const connection=s.voice.connection_id;
   try {await bot.heartbeatVoice({...sessionOptions(s),status:s.player.paused?'Em pausa':s.player.current?`A tocar: ${s.player.current.title}`:'À espera de música'});}
   catch {
    if(s.closing || stopped)return;
    if(s.recovering || s.voice.connection_id!==connection)s.statusPending=true;
    else{try{await close(s);}catch{}bot.emit('error',new Error('music_voice_access_lost'));return;}
   }
   finally {s.heartbeatRunning=false;}
   const changed=s.statusPending;s.statusPending=false;
   if(!s.closing && !stopped)watch(s,changed?0:heartbeatMs);
  },delay);
 };
 const attach=async(ctx,track)=>{
  const existing=sessions.get(ctx.serverId);
  if(existing) {
   // A fresh claimed slash event and server-side actor voice assignment are
   // checked on every control, including queueing and volume changes.
   await ctx.getVoiceState({channelId:existing.voice.channel_id});
   clearIdle(existing);return existing;
  }
  const voice=await ctx.joinVoice({publishAudio:true,status:`A tocar: ${track.title}`});
  const s={voice,player:createPlayer(),timer:null,idleTimer:null,closing:null};
  try {await s.player.connect(voice);}catch(error){try{await close(s);}catch{}throw error;}
  sessions.set(ctx.serverId,s);
  wirePlayer(s,ctx);
  watch(s);return s;
 };
 const wirePlayer=(s,ctx)=>{
  const player=s.player;
  player.on('playbackError',error=>{
   bot.emit('error',new Error('music_playback_failed'));
   void bot.sendMessage({serverId:ctx.serverId,channelId:ctx.channelId,content:musicErrorMessage(error)})
    .catch(()=>bot.emit('error',new Error('music_failure_notice_failed')));
  });
  player.on('closed',()=>{if(s.player===player && !s.closing && !s.recovering)void close(s).catch(()=>bot.emit('error',new Error('music_cleanup_failed')));});
  player.on('reconnecting',()=>{if(s.player===player && !s.closing){clearIdle(s);watch(s,0);}});
  player.on('reconnected',()=>{
   // A transport retry does not grant new authority. Verify the exact lease
   // before releasing PCM frames held by the RTC publisher.
   void serial(ctx.serverId,async()=>{
    if(s.player!==player || s.closing || stopped)return;
    try{await bot.heartbeatVoice({...sessionOptions(s)});if(s.player===player && !s.closing)player.transportReady();}
    catch{await close(s);bot.emit('error',new Error('music_voice_access_lost'));}
   }).catch(()=>bot.emit('error',new Error('music_voice_access_lost')));
  });
  player.on('disconnected',state=>{
   if(s.player!==player || s.closing || stopped || s.recovering)return;
   s.recovering=true;clearTimeout(s.timer);clearIdle(s);
   void serial(ctx.serverId,async()=>{
    try{
     await player.close();
     if(s.closing || stopped)return;
     if(typeof bot.recoverVoice!=='function')throw new Error('music_recovery_unavailable');
     const fresh=await bot.recoverVoice({...sessionOptions(s),status:'A recuperar a música'});
     if(fresh.server_id!==s.voice.server_id || fresh.channel_id!==s.voice.channel_id || fresh.connection_id===s.voice.connection_id)throw new Error('invalid_voice_connection');
     s.voice=fresh;
     if(s.closing || stopped){await bot.closeVoiceConnection(sessionOptions(s));return;}
     const next=createPlayer();s.player=next;wirePlayer(s,ctx);await next.connect(fresh);
     next.setVolume(state.volume);if(state.paused)next.pause();
     for(const track of state.tracks)next.enqueue(track);
     s.recovering=false;watch(s,0);if(!state.tracks.length)next.emit('idle');
    }catch{ s.recovering=false;await close(s);bot.emit('error',new Error('music_voice_recovery_failed'));
     await bot.sendMessage({serverId:ctx.serverId,channelId:ctx.channelId,content:'A ligação de voz caiu e não consegui recuperá-la. Volta a usar /play.'});
    }
   }).catch(()=>bot.emit('error',new Error('music_voice_recovery_failed')));
  });
  player.on('track',()=>{clearIdle(s);watch(s,0);});
  player.on('playing',track=>{
   const timing=timings.get(track);if(!timing)return;timings.delete(track);
   const {started,...durations}=timing;bot.emit('musicTiming',{...durations,firstAudioMs:Math.round(performance.now()-started)});
  });
  player.on('idle',()=>{if(!s.closing && !s.recovering){
   clearIdle(s);watch(s,0);const epoch=s.idleEpoch;
   s.idleTimer=setTimeout(()=>{void serial(ctx.serverId,()=>{
    // A timer may already be queued behind a slow source lookup when /play
    // cancels it. Never retire the session after that newer enqueue.
    if(s.closing || s.idleEpoch!==epoch || s.player.current || s.player.queue?.length || pendingFor(ctx.serverId).length)return;
    return close(s);
   }).catch(()=>bot.emit('error',new Error('music_cleanup_failed')));},idleMs);
  }});
 };
 const command=(name,metadata,fn)=>bot.command(name,metadata,ctx=>serial(ctx.serverId,async()=>{
  try {if(stopped)throw new Error('music_stopped');await fn(ctx);}
  catch(error){
   const message=musicErrorMessage(error);
   bot.emit('error',new Error(`music_command_failed:${name}`));
   if(!ctx.replied)await ctx.reply(message);
  }
 }));
 const active=async ctx=>{
  const s=sessions.get(ctx.serverId);if(!s)throw new Error('music_not_connected');
  await ctx.getVoiceState({channelId:s.voice.channel_id});if(s.recovering)throw new Error('music_recovering');return s;
 };
 bot.command('play',{description:'Toca uma música ou junta-a à fila',options:[{name:'faixa',description:'Nome, link YouTube/Spotify, playlist ou faixa local',type:'STRING',required:false}]},async ctx=>{
  const value=ctx.option('faixa') || ctx.option('text') || 'teste';
  const local=catalogue.get(value) || [...catalogue.values()].find(t=>t.title.toLowerCase()===value.toLowerCase());
  const started=performance.now();let job;
  try{
   if(stopped)throw new Error('music_stopped');
   const existing=sessions.get(ctx.serverId);
   const state=await ctx.getVoiceState({channelId:existing?.voice.channel_id || ''});
   if((existing?.player.queue?.length||0)+pendingFor(ctx.serverId).length>=20 || pendingFor(ctx.serverId).length>=5)throw new Error('music_queue_full');
   job={ctx,cancel:new AbortController(),channelId:existing?.voice.channel_id || state?.channel_id || '',started};
   if(!pending.has(ctx.serverId))pending.set(ctx.serverId,new Set());pending.get(ctx.serverId).add(job);
   if(existing)clearIdle(existing);
   // Replying finalizes the interaction. Keep it claimed until voice admission
   // has been rechecked after the external lookup and the bot has joined.
   if(!local){
    try{const notice=await ctx.sendMessage('A preparar a música… 🎵');job.messageId=notice?.message?.id;}
    catch{bot.emit('error',new Error('music_progress_notice_failed'));}
   }
   const finish=async message=>{
    const result=ctx.replied?await ctx.sendMessage(message):await ctx.reply(message);
    if(job.messageId){
     try{await ctx.deleteMessage(job.messageId);}
     catch{
      // Optional own-message permissions must not turn successful playback
      // into a failed command or leave the progress text claiming work continues.
      try{await ctx.editMessage(job.messageId,'Este pedido de música já foi processado.');}
      catch{bot.emit('error',new Error('music_progress_cleanup_failed'));}
     }
    }
    return result;
   };
   const previous=lookups.get(ctx.serverId)||Promise.resolve();
   const task=previous.catch(()=>{}).then(async()=>{
    const signal=AbortSignal.any([shutdown.signal,job.cancel.signal,AbortSignal.timeout(25000)]);signal.throwIfAborted();
    const lookupStart=performance.now();
    const batch=local?{tracks:[local]}:sources.resolveBatch?await cancellable(sources.resolveBatch(value,signal),signal):{tracks:[await cancellable(sources.resolve(value,signal),signal)]};
    const lookupMs=Math.round(performance.now()-lookupStart);signal.throwIfAborted();
    let response;
    await serial(ctx.serverId,async()=>{
     signal.throwIfAborted();if(stopped)throw new Error('music_stopped');
     // Admission is rechecked after resolution and inside the short mutation
     // lock. /stop can cancel a slow lookup before it ever joins or enqueues.
     await ctx.getVoiceState({channelId:job.channelId});signal.throwIfAborted();
     const voiceStart=performance.now(),s=await attach(ctx,batch.tracks[0]);signal.throwIfAborted();
     if((s.player.queue?.length||0)+batch.tracks.length>20)throw new Error('music_queue_full');
     timings.set(batch.tracks[0],{started,lookupMs,voiceMs:Math.round(performance.now()-voiceStart),totalMs:Math.round(performance.now()-started)});
     for(const track of batch.tracks)s.player.enqueue(track);
     const track=batch.tracks[0];
     response={embeds:[{title:'Música 🎵',description:batch.title?`Adicionadas ${batch.tracks.length} faixas: **${batch.title}**${batch.truncated?'\nA coleção foi limitada às primeiras 20 faixas.':''}`:`Adicionada: **${track.title}**`,color:0xe9cfaa,
   fields:[...(track.url?[{name:'Fonte',value:`[Abrir YouTube](${track.url})${track.requestedUrl?`\nPedido: [${track.requestedTitle}](${track.requestedUrl})`:''}`}]:[]),
    {name:'Volume',value:`${s.player.status().volume}%`,inline:true},{name:'Controlos',value:'/pause · /resume · /skip · /queue · /volume · /stop'}]}]};
    });
    await finish(response);
   }).catch(async error=>{
    bot.emit('musicTiming',{lookupMs:null,voiceMs:null,totalMs:Math.round(performance.now()-started),cancelled:job.cancel.signal.aborted || stopped});
    if(!job.cancel.signal.aborted && !stopped)bot.emit('error',new Error('music_command_failed:play'));
    try{await finish(job.cancel.signal.aborted || stopped?'Pedido de música cancelado.':musicErrorMessage(error));}
    catch{bot.emit('error',new Error('music_failure_notice_failed'));}
   }).finally(()=>{
    pending.get(ctx.serverId)?.delete(job);if(!pending.get(ctx.serverId)?.size)pending.delete(ctx.serverId);tasks.delete(task);if(lookups.get(ctx.serverId)===task)lookups.delete(ctx.serverId);
    const s=sessions.get(ctx.serverId);if(s && !s.closing && !s.recovering && !s.player.current && !s.player.queue?.length && !pendingFor(ctx.serverId).length)s.player.emit('idle');
   });
   lookups.set(ctx.serverId,task);tasks.add(task);
   // Return after acknowledgment so the SDK can poll pause/stop while the
   // external lookup runs. Local files keep their immediate completion path.
   if(local || !job.messageId)await task;
  }catch(error){pending.get(ctx.serverId)?.delete(job);if(!pending.get(ctx.serverId)?.size)pending.delete(ctx.serverId);if(!ctx.replied)await ctx.reply(musicErrorMessage(error));}
 });
 command('pause',{description:'Pausa a música'},async ctx=>{const s=await active(ctx);s.player.pause();watch(s,0);await ctx.reply('Música em pausa. ⏸️');});
 command('resume',{description:'Retoma a música'},async ctx=>{const s=await active(ctx);s.player.resume();watch(s,0);await ctx.reply('Música retomada. ▶️');});
 command('skip',{description:'Passa à próxima música'},async ctx=>{(await active(ctx)).player.skip();await ctx.reply('A passar à próxima música. ⏭️');});
 command('volume',{description:'Ajusta o volume da música',options:[{name:'nivel',description:'Volume de 0 a 100',type:'INTEGER',required:true,min_value:0,max_value:100}]},async ctx=>{
  const level=ctx.option('nivel');if(!/^\d{1,3}$/.test(level))throw new Error('invalid_music_volume');
  const s=await active(ctx);s.player.setVolume(Number(level));await ctx.reply(`Volume: ${s.player.status().volume}%. 🔊`);
 });
 command('queue',{description:'Mostra a fila de músicas'},async ctx=>{
  const status=(await active(ctx)).player.status();
  await ctx.reply({embeds:[{title:'Fila de músicas 🎶',description:`Agora: ${status.current || 'Nada a tocar'}${status.paused?' (em pausa)':''}`,
   fields:[{name:'A seguir',value:status.queue.map((name,i)=>`${i+1}. ${name}`).join('\n').slice(0,1000)||'A fila está vazia.'}],color:0xe9cfaa}]});
 });
 command('stop',{description:'Cancela pedidos, limpa a fila e sai da voz'},async ctx=>{
  const s=sessions.get(ctx.serverId),jobs=pendingFor(ctx.serverId);
  if(!s && !jobs.length)throw new Error('music_not_connected');
  await ctx.getVoiceState({channelId:s?.voice.channel_id || jobs[0]?.channelId || ''});cancelPending(ctx.serverId);
  if(s)await close(s);await ctx.reply('Música parada. Pedidos e fila cancelados. 👋');
 });
 return {sessions,catalogue,pending,async settle(){await Promise.allSettled([...tasks]);},async stop(){stopped=true;shutdown.abort();for(const server of pending.keys())cancelPending(server);await Promise.allSettled([...tasks]);await Promise.allSettled([...locks.values()]);const results=await Promise.allSettled([...sessions.values()].map(close));if(results.some(r=>r.status==='rejected'))throw new Error('music_cleanup_failed');}};
}
function musicErrorMessage(error) {
 const code=String(error?.code || error?.message || '');
 if(/user_not_in_voice/.test(code))return 'Entra no canal de voz onde está o bot e volta a tentar.';
 if(/music_queue_full/.test(code))return 'A fila já tem 20 músicas. Espera ou usa /skip.';
 if(/invalid_music_volume/.test(code))return 'Usa um volume entre 0 e 100.';
 if(/music_not_connected/.test(code))return 'Ainda não estou a tocar. Começa com /play.';
 if(/music_recovering/.test(code))return 'Estou a recuperar a ligação de voz. Tenta novamente daqui a pouco.';
 if(/invalid_voice_connection|PGRST202|voice_media_not_ready/.test(code))return 'O suporte de áudio do servidor ainda precisa de ser ativado.';
 if(/music_extractor_missing/.test(code))return 'O bot precisa de instalar yt-dlp para tocar links e pesquisas. Consulta o guia do bot de música.';
 if(/music_spotify_match_failed/.test(code))return 'Não encontrei uma versão correspondente à faixa Spotify. Experimenta um link YouTube direto.';
 if(/music_spotify_unavailable/.test(code))return 'Não consegui identificar esta faixa Spotify. Experimenta o nome e o artista ou um link YouTube.';
 if(/music_link_unsupported|music_input_invalid|music_source_unsafe/.test(code))return 'Usa um nome de música ou um link completo de uma faixa YouTube/Spotify.';
 if(/music_source_blocked/.test(code))return 'A fonte bloqueou o acesso ao áudio. Experimenta outra faixa; o bot pode precisar de atualizar yt-dlp.';
 if(/music_source_timeout|TimeoutError/.test(code))return 'A pesquisa demorou demasiado. Tenta novamente ou usa um link YouTube direto.';
 if(/music_track_unavailable/.test(code))return 'Esta faixa não tem áudio disponível ou ultrapassa o limite de 30 minutos.';
 if(/music_source_unavailable|music_source_too_large/.test(code))return 'Não consegui obter o áudio desta faixa. Experimenta outro link ou pesquisa.';
 if(/music_decode_failed|music_file_unavailable|music_decoder_unavailable/.test(code))return 'Não consegui ler o áudio desta faixa. Verifica o ficheiro e o FFmpeg do bot.';
 return 'Não consegui completar o comando de música. Tenta novamente.';
}
module.exports={registerMusicCommands};

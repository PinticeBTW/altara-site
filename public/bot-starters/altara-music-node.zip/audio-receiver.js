const {EventEmitter}=require('node:events');
const fs=require('node:fs'),path=require('node:path');
const {randomUUID}=require('node:crypto');
const UUID='[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';
const humanIdentity=new RegExp(`^capture-user:(${UUID}):(${UUID})$`,'i');
function wavHeader(bytes){const b=Buffer.alloc(44);b.write('RIFF');b.writeUInt32LE(bytes+36,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(48000,24);b.writeUInt32LE(96000,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(bytes,40);return b;}
class AltaraAudioReceiver extends EventEmitter{
 constructor({rtc=null,recordingDirectory=null,onFrame=()=>{},heartbeat=async()=>{},closeLease=async()=>{}}={}){
  super();this.rtc=rtc;this.directory=recordingDirectory;this.onFrame=onFrame;this.heartbeat=heartbeat;this.closeLease=closeLease;this.streams=new Map();this.closed=false;
 }
 async connect(lease){
  if(this.room || this.closed)throw Error('receiver_already_used');
  if(lease.room_name!==`bot-audio:${lease.bot_id}:${lease.server_id}:${lease.channel_id}:${lease.capture_id}`
   || lease.can_publish_audio!==false || lease.can_subscribe_audio!==true || !/^wss:\/\//.test(lease.livekit_url) || !lease.token)throw Error('invalid_capture_lease');
  if(lease.recording && !this.directory)throw Error('recording_directory_required');
  if(this.directory){fs.mkdirSync(this.directory,{recursive:true});this.root=fs.realpathSync(this.directory);}
  this.rtc ||= require('@livekit/rtc-node');this.lease={...lease,token:undefined,livekit_url:undefined};this.room=new this.rtc.Room();
  this.onPublished=(publication,participant)=>{
   if(humanIdentity.test(participant?.identity||'') && publication.source===this.rtc.TrackSource.SOURCE_MICROPHONE && this.streams.size<8)publication.setSubscribed(true);
  };
  this.onSubscribed=(track,publication,participant)=>{void this.consume(track,publication,participant).catch(()=>this.emit('captureError',new Error('audio_capture_failed')));};
  this.onUnsubscribed=(_track,_publication,participant)=>{const s=this.streams.get(participant?.identity);if(s)void s.reader.cancel().catch(()=>{});};
  this.onDisconnected=()=>{void this.close().catch(()=>this.emit('captureError',new Error('audio_capture_cleanup_failed')));};
  this.room.on(this.rtc.RoomEvent.TrackPublished,this.onPublished);this.room.on(this.rtc.RoomEvent.TrackSubscribed,this.onSubscribed);
  this.room.on(this.rtc.RoomEvent.TrackUnsubscribed,this.onUnsubscribed);this.room.on(this.rtc.RoomEvent.Disconnected,this.onDisconnected);
  try{
   await this.room.connect(lease.livekit_url,lease.token,{autoSubscribe:false,dynacast:false});
   for(const p of this.room.remoteParticipants.values())for(const pub of p.trackPublications.values())this.onPublished(pub,p);
   this.timer=setTimeout(()=>{void this.renew().catch(()=>this.emit('captureError',new Error('audio_capture_access_lost')));},10000);
   this.limit=setTimeout(()=>{void this.close().catch(()=>this.emit('captureError',new Error('audio_capture_cleanup_failed')));},30*60*1000);
  }catch{await this.close();throw Error('audio_capture_connect_failed');}
  return this;
 }
 async renew(){
  if(this.closed)return;
  try{const result=await this.heartbeat(this.lease);if(result.capture_id!==this.lease.capture_id || result.room_name!==this.lease.room_name)throw Error('invalid_capture_lease');
   if(!this.closed)this.timer=setTimeout(()=>{void this.renew().catch(()=>this.emit('captureError',new Error('audio_capture_access_lost')));},10000);
  }catch{await this.close();this.emit('captureError',new Error('audio_capture_access_lost'));}
 }
 async consume(track,publication,participant){
  const identity=participant?.identity||'',match=humanIdentity.exec(identity);
  if(this.closed || !match || publication.source!==this.rtc.TrackSource.SOURCE_MICROPHONE || this.streams.has(identity) || this.streams.size>=8)return;
  const stream=new this.rtc.AudioStream(track,{sampleRate:48000,numChannels:1,frameSizeMs:20}),reader=stream.getReader();
  const state={reader,bytes:0,fd:null,done:null};this.streams.set(identity,state);
  if(this.lease.recording){
   // The operator selects the directory. No request, username or network path
   // can select a recording filename, and exclusive creation preserves files.
   try{const filename=path.join(this.root,`capture-${randomUUID()}.wav`);state.fd=fs.openSync(filename,'wx',0o600);fs.writeSync(state.fd,wavHeader(0));}
   catch{await reader.cancel();reader.releaseLock();this.streams.delete(identity);throw Error('recording_file_unavailable');}
  }
  state.done=(async()=>{
   try{while(!this.closed){const {value:frame,done}=await reader.read();if(done || this.closed)break;
    if(frame.sampleRate!==48000 || frame.channels!==1 || !(frame.data instanceof Int16Array) || frame.data.length>48000)throw Error('invalid_capture_frame');
    const data=Buffer.alloc(frame.data.length*2);for(let i=0;i<frame.data.length;i++)data.writeInt16LE(frame.data[i],i*2);
    if(state.bytes+data.length>30*60*96000)throw Error('capture_limit_reached');
    if(state.fd!==null){let offset=0;while(offset<data.length){const written=fs.writeSync(state.fd,data,offset,data.length-offset);if(written<=0)throw Error('recording_file_unavailable');offset+=written;state.bytes+=written;}}
    else state.bytes+=data.length;
    await this.onFrame({userId:match[1],consentId:match[2],sampleRate:48000,channels:1,data:new Int16Array(frame.data)});
   }}finally{
    try{await reader.cancel().catch(()=>{});reader.releaseLock();}
    finally{
     try{if(state.fd!==null)try{fs.writeSync(state.fd,wavHeader(state.bytes),0,44,0);}finally{fs.closeSync(state.fd);}}
     finally{if(this.streams.get(identity)===state)this.streams.delete(identity);}
    }
   }
  })();return state.done;
 }
 async close(){
  if(this.closing)return this.closing;this.closed=true;clearTimeout(this.timer);clearTimeout(this.limit);
  this.closing=(async()=>{
   if(this.room){for(const [event,fn] of [[this.rtc.RoomEvent.TrackPublished,this.onPublished],[this.rtc.RoomEvent.TrackSubscribed,this.onSubscribed],[this.rtc.RoomEvent.TrackUnsubscribed,this.onUnsubscribed],[this.rtc.RoomEvent.Disconnected,this.onDisconnected]])this.room.off(event,fn);}
   await Promise.allSettled([...this.streams.values()].map(s=>s.reader.cancel()));
   await Promise.allSettled([...this.streams.values()].map(s=>s.done));
   const errors=[];try{await this.room?.disconnect();}catch{errors.push('provider');}
   try{if(this.lease)await this.closeLease(this.lease);}catch{errors.push('lease');}this.emit('closed');
   if(errors.length)throw Error('audio_capture_cleanup_failed');
  })();return this.closing;
 }
}
module.exports={AltaraAudioReceiver,wavHeader};

const answers = Object.freeze({
  regras: "Respeita os outros membros e as regras do servidor. Contacta a equipa se precisares de ajuda.",
  ajuda: "Explica o problema à equipa do servidor, sem partilhar passwords ou tokens.",
  bots: "Escolhe um comando começado por / para falar com os bots deste servidor.",
});

function answerFaq(topic) {
  const key = String(topic || "").trim().toLowerCase();
  return Object.hasOwn(answers, key) ? answers[key] : "Tema desconhecido. Escolhe regras, ajuda ou bots.";
}

module.exports = { answerFaq, topics: Object.keys(answers) };

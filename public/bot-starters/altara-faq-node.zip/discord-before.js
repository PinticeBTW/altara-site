// Reference adapter: install discord.js separately to run against a test guild.
const { Client, Events, GatewayIntentBits, SlashCommandBuilder } = require("discord.js");
const { answerFaq, topics } = require("./faq");

async function start() {
  const token = process.env.DISCORD_BOT_TOKEN;
  const guildId = process.env.DISCORD_TEST_GUILD_ID;
  if (!token || !guildId) throw new Error("Set DISCORD_BOT_TOKEN and DISCORD_TEST_GUILD_ID");
  const client = new Client({ intents: [GatewayIntentBits.Guilds] });
  client.once(Events.ClientReady, async () => {
    try {
      const guild = await client.guilds.fetch(guildId);
      const command = new SlashCommandBuilder().setName("faq").setDescription("Responde a dúvidas sobre o servidor")
        .addStringOption(option => option.setName("tema").setDescription("O que queres saber?").setRequired(true)
          .addChoices(...topics.map(value => ({ name: value, value }))));
      // Upsert this command only; preserve unrelated commands in the test guild.
      await guild.commands.create(command.toJSON());
    } catch (error) { console.error("[faq]", error.message); client.destroy(); }
  });
  client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isChatInputCommand() || interaction.commandName !== "faq") return;
    try { await interaction.reply(answerFaq(interaction.options.getString("tema", true))); }
    catch (error) { console.error("[faq]", error.message); }
  });
  await client.login(token);
}

if (require.main === module) start().catch(error => { console.error(error.message); process.exitCode = 1; });

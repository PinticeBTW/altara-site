# FAQ bot: Discord to ALTARA (JavaScript)

This is a complete small example with two platform adapters. It is newly written
reference code, not a third-party bot imported automatically from Discord.
`faq.js` contains the same answers for both platforms; change those answers for
your server. `index.js` uses ALTARA; `discord-before.js` uses discord.js.

## Run on ALTARA

Use Node.js 22.12 or later. Extract the whole download; keep `altara.js` and
`altara-client.js` beside `index.js`. In the source repository the wrapper loads
the existing client from the neighbouring ping example.

1. Create a new test bot in the ALTARA Developer Portal and copy its token once.
2. Keep the four default permissions and install it in a test server.
3. Copy `.env.example` to `.env` and set `ALTARA_BOT_TOKEN`.
4. Run `npm start` (there are no ALTARA dependencies to install for this example).
5. Run `/faq regras`, `/faq ajuda` and `/faq bots` in ALTARA. Stop with Ctrl+C.

PowerShell: `Copy-Item .env.example .env`. macOS/Linux: `cp .env.example .env`.
Never commit `.env`. Replacing the token requires restarting the process.

## Compare the Discord adapter

Install `discord.js` separately with `npm install --no-save discord.js`, set
`DISCORD_BOT_TOKEN` and `DISCORD_TEST_GUILD_ID` in `.env`, install that Discord
application with `bot` and `applications.commands` in your test guild, then run
`npm run discord`. This upserts `/faq` in that guild without deleting other
commands. It needs a separate Discord token; ALTARA tokens do not work there.

Both adapters call `answerFaq(topic)`. The migration changes command registration,
option reading and replying. It preserves the business logic. ALTARA syncs its
code registry at startup and disables missing code-managed commands, so run this
example on a dedicated bot rather than on a bot with other commands.

## Verification

The ALTARA adapter is tested for command sync, delivery and replies against a local
HTTP test server with fake credentials. The Discord adapter is reference code;
no live Discord session or third-party bot migration is claimed.

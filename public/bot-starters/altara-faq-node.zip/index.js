const { AltaraClient } = require("./altara");
const { answerFaq, topics } = require("./faq");

function createBot(options = {}) {
  const bot = new AltaraClient({ token: process.env.ALTARA_BOT_TOKEN, ...options });
  bot.command("faq", {
    description: "Responde a dúvidas sobre o servidor",
    options: [{ name: "tema", description: "O que queres saber?", type: "STRING", required: true,
      choices: topics.map(value => ({ name: value, value })) }],
  }, async ctx => ctx.reply(answerFaq(ctx.option("tema"))));
  return bot;
}

if (require.main === module) {
  const bot = createBot();
  bot.on("error", error => console.error("[faq]", error.message));
  process.once("SIGINT", () => bot.stop());
  process.once("SIGTERM", () => bot.stop());
  bot.login();
}

module.exports = { createBot };

import os
import discord
from discord import app_commands
from calculator import OPERATIONS, calculate


class CalculatorClient(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.default())
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        # Guild-specific command on a dedicated test app: keep sync away from production.
        guild = discord.Object(id=int(os.environ["DISCORD_TEST_GUILD_ID"]))

        @self.tree.command(name="calcular", description="Faz uma conta simples", guild=guild)
        @app_commands.choices(operacao=[app_commands.Choice(name=value, value=value) for value in OPERATIONS])
        async def calcular(interaction: discord.Interaction, operacao: str, a: float, b: float):
            await interaction.response.send_message(calculate(operacao, a, b))

        await self.tree.sync(guild=guild)


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    CalculatorClient().run(os.environ["DISCORD_BOT_TOKEN"])

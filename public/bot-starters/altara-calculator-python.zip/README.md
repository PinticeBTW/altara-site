# Calculator bot: Discord to ALTARA (Python)

This newly written reference example uses `calculator.py` on both platforms.
`main.py` registers ALTARA commands; `discord_before.py` shows the Discord adapter.
No third-party bot or live Discord migration is implied.

## Run on ALTARA

Use Python 3.10 or later. Extract the whole download; keep `altara.py` beside
`main.py`. Source checkouts reuse the canonical neighbouring ping client.

1. Create a dedicated test bot, copy its ALTARA token, retain the four default
   permissions and install it in a test server.
2. Create an environment: `python -m venv .venv`.
3. Activate it: PowerShell `.\.venv\Scripts\Activate.ps1`;
   macOS/Linux `source .venv/bin/activate`.
4. Run `python -m pip install -r requirements.txt`.
5. Copy `.env.example` to `.env` and set `ALTARA_BOT_TOKEN`.
6. Run `python main.py`. Stop with Ctrl+C.

PowerShell copies with `Copy-Item .env.example .env`; macOS/Linux uses
`cp .env.example .env`. Keep `.env` private.

Try `/calcular` with `operacao=somar`, `a=1.2`, `b=2.3`: expect `Resultado: 3.5`.
Try dividing by zero: expect a readable error. Pick options in the command UI.
Only the four listed operations and bounded decimal numbers are accepted.
Expressions, Python code, NaN and Infinity are not accepted.

## Compare the Discord adapter

Use a dedicated Discord test application and guild. Install `discord.py` with
`python -m pip install discord.py`, set `DISCORD_BOT_TOKEN` and
`DISCORD_TEST_GUILD_ID` in `.env`, install the app with `bot` and
`applications.commands`, then run `python discord_before.py`. Guild sync
replaces that application's command registry in the test guild.

Both adapters call `calculate(operation, a, b)`. Reuse that function during a
migration; replace command decorators, option access, token and transport.
ALTARA startup sync disables missing code-managed commands, so use a dedicated
bot here. Tokens and server/channel IDs are different on the two platforms.

## Verification

Tests exercise ALTARA command sync, event delivery and reply payloads using fake
HTTP responses, plus decimal arithmetic and rejected inputs. No live Discord
session or hosted bot lifecycle is claimed.

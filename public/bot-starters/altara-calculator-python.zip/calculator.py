import re
from decimal import Decimal, localcontext

OPERATIONS = ("somar", "subtrair", "multiplicar", "dividir")


def calculate(operation, a, b):
    """Bounded decimal arithmetic; user input is never executed as code."""
    operation = str(operation or "").strip().lower()
    if operation not in OPERATIONS:
        return "Operação inválida. Escolhe somar, subtrair, multiplicar ou dividir."
    values = []
    for value in (a, b):
        text = str(value if value is not None else "").strip()
        if len(text) > 20 or not re.fullmatch(r"[+-]?\d{1,12}(?:\.\d{1,6})?", text, flags=re.ASCII):
            return "Usa números com até 12 algarismos inteiros e 6 casas decimais."
        values.append(Decimal(text))
    left, right = values
    if operation == "dividir" and right == 0:
        return "Não é possível dividir por zero."
    with localcontext() as context:
        context.prec = 40
        if operation == "somar": result = left + right
        elif operation == "subtrair": result = left - right
        elif operation == "multiplicar": result = left * right
        else: result = left / right
        return f"Resultado: {format(result.normalize(), 'f')}"

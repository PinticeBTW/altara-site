import os
import sys
from pathlib import Path

# Downloads contain altara.py locally; source checkouts reuse the canonical client.
if not Path(__file__).with_name("altara.py").is_file():
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "altara-ping-bot-python"))
from altara import AltaraClient
from calculator import OPERATIONS, calculate


def create_bot(**options):
    bot = AltaraClient(**{"token": os.getenv("ALTARA_BOT_TOKEN"), **options})

    @bot.command("calcular", description="Faz uma conta simples", options=[
        {"name": "operacao", "description": "Tipo de conta", "type": "STRING", "required": True,
         "choices": [{"name": value, "value": value} for value in OPERATIONS]},
        {"name": "a", "description": "Primeiro número", "type": "NUMBER", "required": True},
        {"name": "b", "description": "Segundo número", "type": "NUMBER", "required": True},
    ])
    async def calcular(ctx):
        await ctx.reply(calculate(ctx.option("operacao"), ctx.option("a"), ctx.option("b")))

    return bot


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    create_bot().run()

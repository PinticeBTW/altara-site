const crypto = require("crypto");

function rawBodySaver(req, res, buf) {
  req.rawBody = Buffer.from(buf);
}

function timingSafeEqualString(a, b) {
  const left = Buffer.from(String(a || ""));
  const right = Buffer.from(String(b || ""));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function verifyAltaraSignature(req, signingSecret) {
  if (!signingSecret) return false;

  const timestamp = String(req.get("X-Altara-Timestamp") || "");
  const signature = String(req.get("X-Altara-Signature") || "");
  const rawBody = req.rawBody;
  const timestampMs = Date.parse(timestamp);

  if (!timestamp || !signature || !Buffer.isBuffer(rawBody) || !rawBody.length || !Number.isFinite(timestampMs)) return false;
  if (Math.abs(Date.now() - timestampMs) > 5 * 60 * 1000) return false;

  const expected = "v1=" + crypto
    .createHmac("sha256", signingSecret)
    .update(`${timestamp}.`)
    .update(rawBody)
    .digest("hex");

  return timingSafeEqualString(signature, expected);
}

function rollDice(input = "1d20") {
  const text = String(input || "1d20").trim().toLowerCase();
  const match = text.match(/^(\d{0,2})d(\d{1,4})$/);
  if (!match) return null;

  const count = Number(match[1] || 1);
  const sides = Number(match[2]);
  if (!Number.isInteger(count) || !Number.isInteger(sides) || count < 1 || count > 20 || sides < 2 || sides > 1000) {
    return null;
  }

  const rolls = Array.from({ length: count }, () => 1 + Math.floor(Math.random() * sides));
  const total = rolls.reduce((sum, value) => sum + value, 0);
  return { dice: `${count}d${sides}`, rolls, total };
}

function reply(message) {
  const input = typeof message === "string" ? { content: message } : message;
  if (!input || typeof input !== "object" || Array.isArray(input)) throw Error("invalid_webhook_reply");
  // Do not silently strip a response type or private intent into a public reply.
  if (Object.keys(input).some(key => !["content", "embeds", "components", "attachments", "allowed_mentions", "ephemeral"].includes(key))) throw Error("unsupported_webhook_reply");
  if (input.ephemeral !== undefined && typeof input.ephemeral !== "boolean") throw Error("invalid_ephemeral");
  if (input.content !== undefined && typeof input.content !== "string") throw Error("invalid_webhook_reply");
  if (input.embeds !== undefined && (!Array.isArray(input.embeds) || input.embeds.length > 10
    || input.embeds.some(card => !card || typeof card !== "object" || Array.isArray(card)))) throw Error("invalid_webhook_reply");
  const data = { content: (input.content || "").slice(0, 2000) };
  if (input.components !== undefined && (!Array.isArray(input.components) || input.components.length > 5
    || input.components.some(row => !row || typeof row !== "object" || Array.isArray(row)))) throw Error("invalid_webhook_reply");
  if (input.attachments !== undefined) {
    if (!Array.isArray(input.attachments) || input.attachments.length > 10) throw Error("invalid_webhook_reply");
    const ids = new Set();
    data.attachments = input.attachments.map(item => {
      const id = typeof item === 'string' ? item : item?.upload_id;
      if (typeof id !== 'string' || !webhookUuid.test(id)
        || (typeof item !== 'string' && (!item || Array.isArray(item) || Object.keys(item).some(key => key !== 'upload_id')))
        || ids.has(id.toLowerCase())) throw Error("invalid_webhook_reply");
      ids.add(id.toLowerCase()); return { upload_id: id.toLowerCase() };
    });
  }
  if (input.allowed_mentions !== undefined) {
    const mentions = input.allowed_mentions;
    if (!mentions || typeof mentions !== 'object' || Array.isArray(mentions)
      || Object.keys(mentions).some(key => key !== 'users') || !Array.isArray(mentions.users)
      || mentions.users.length > 20 || mentions.users.some(id => typeof id !== 'string' || !webhookUuid.test(id))
      || new Set(mentions.users.map(id => id.toLowerCase())).size !== mentions.users.length) throw Error("invalid_webhook_reply");
    data.allowed_mentions = { users: mentions.users.map(id => id.toLowerCase()) };
  }
  if (!data.content.trim() && !input.embeds?.length && !input.components?.length && !data.attachments?.length) throw Error("invalid_webhook_reply");
  // ALTARA still validates card properties, limits and channel grants.
  if (input.embeds !== undefined) data.embeds = input.embeds;
  if (input.components !== undefined) data.components = input.components;
  if (input.ephemeral !== undefined) data.ephemeral = input.ephemeral;
  return { type: "CHANNEL_MESSAGE_WITH_SOURCE", data };
}

const webhookUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function interactionRequest(event, apiBase, fetchImpl, error) {
  const id = event?.id || event?.event_id;
  if (typeof id !== 'string' || !webhookUuid.test(id) || (event?.id && event?.event_id && event.id !== event.event_id)
    || typeof event?.token !== 'string' || !/^altara_interaction_[a-f0-9]{48}$/.test(event.token)
    || typeof apiBase !== 'string' || typeof fetchImpl !== 'function') throw Error(error);
  let base;
  try { base = new URL(apiBase); } catch { throw Error(error); }
  if (base.protocol !== 'https:' || base.username || base.password || base.search || base.hash) throw Error(error);
  return { id, token: event.token, base: base.href.replace(/\/$/, '') };
}
function nativeSource(event) {
  if(event?.source_kind===undefined)return {};
  if(!['dm','thread'].includes(event.source_kind))throw Error('invalid_native_interaction_source');
  return {source_kind:event.source_kind};
}

async function followUpReply(event, message, { apiBase, requestId, fetchImpl = globalThis.fetch } = {}) {
  const scope = interactionRequest(event, apiBase, fetchImpl, 'invalid_interaction_followup');
  if (typeof requestId !== 'string' || !webhookUuid.test(requestId)) throw Error('invalid_interaction_followup');
  // Freeze the request before the first await; an uncertain retry must retain
  // this UUID and exact payload. Never retry a possibly accepted write here.
  let body;
  try { body = JSON.stringify({ action: 'followup_interaction', event_id: scope.id, request_id: requestId.toLowerCase(), response: reply(message),...nativeSource(event) }); }
  catch { throw Error('invalid_interaction_followup'); }
  const headers = { 'Content-Type': 'application/json', Authorization: 'Interaction ' + scope.token };
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 3000);
  try {
    const result = await fetchImpl(scope.base + '/altara-bot-respond', { method: 'POST', redirect: 'error', credentials: 'omit', signal: controller.signal, headers, body });
    const receipt = await result.json();
    if (!result.ok || receipt?.ok !== true || !webhookUuid.test(receipt.response_id || '')
      || typeof receipt.private_response !== 'boolean' || typeof receipt.replayed !== 'boolean') throw Error();
    return { ok: true, response_id: receipt.response_id, private_response: receipt.private_response, replayed: receipt.replayed };
  } catch { throw Error('interaction_followup_failed'); }
  finally { clearTimeout(timer); }
}

async function uploadInteractionAttachment(event, options = {}) {
  if (!options || typeof options !== 'object' || Array.isArray(options)
    || Object.keys(options).some(key => !['apiBase', 'fetchImpl', 'ephemeral', 'requestId', 'mime', 'fileName', 'file', 'filePath'].includes(key))) throw Error('invalid_interaction_attachment');
  const { apiBase, fetchImpl = globalThis.fetch } = options;
  const scope = interactionRequest(event, apiBase, fetchImpl, 'invalid_interaction_attachment');
  const native = nativeSource(event);
  const ephemeral = options.ephemeral, requestId = options.requestId, filePath = options.filePath;
  if (typeof ephemeral !== 'boolean' || typeof requestId !== 'string' || !webhookUuid.test(requestId)) throw Error('invalid_interaction_attachment');
  const mime = String(options.mime || options.file?.type || 'application/octet-stream');
  const name = String(options.fileName || options.file?.name || 'file').trim();
  if (!name || name.length > 180 || /[\x00-\x1f\x7f\\/]/.test(name) || !mime || mime.length > 128 || /[\r\n]/.test(mime)) throw Error('invalid_interaction_attachment');
  let file = options.file;
  if (filePath !== undefined) {
    if (typeof filePath !== 'string' || !filePath || options.file !== undefined) throw Error('invalid_interaction_attachment');
    const fs = require('node:fs/promises');
    try {
      const stat = await fs.stat(filePath);
      if (!stat.isFile() || stat.size <= 0 || stat.size > 8 * 1024 * 1024) throw Error();
      file = await fs.readFile(filePath);
    } catch { throw Error('interaction_attachment_read_failed'); }
  }
  if (!(file instanceof Blob)) {
    if (!(file instanceof Uint8Array) || !file.byteLength || file.byteLength > 8 * 1024 * 1024) throw Error('invalid_interaction_attachment');
    file = new Blob([file], { type: mime });
  }
  if (!file.size || file.size > 8 * 1024 * 1024) throw Error('invalid_interaction_attachment');
  const form = new FormData();
  form.set('event_id', scope.id); form.set('request_id', requestId.toLowerCase()); form.set('ephemeral', ephemeral ? 'true' : 'false'); form.set('file_name', name); form.set('file', file, name);
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 30000);
  try {
    const result = await fetchImpl(scope.base + (native.source_kind?'/altara-bot-surface-attachments':'/altara-bot-interaction-attachments'), { method: 'POST', redirect: 'error', credentials: 'omit', signal: controller.signal,
      headers: { Authorization: 'Interaction ' + scope.token }, body: form });
    const receipt = await result.json();
    if (!result.ok || receipt?.ok !== true || !webhookUuid.test(receipt.attachment?.upload_id || '')) throw Error();
    return { upload_id: receipt.attachment.upload_id };
  } catch { throw Error('interaction_attachment_upload_failed'); }
  finally { clearTimeout(timer); }
}

function update(message) {
  if (!message || typeof message !== "object" || Array.isArray(message)
    || Object.keys(message).some(key => !["content", "embeds", "components"].includes(key))) throw Error("invalid_webhook_update");
  if (message.content !== undefined && typeof message.content !== "string") throw Error("invalid_webhook_update");
  if (message.embeds !== undefined && (!Array.isArray(message.embeds) || message.embeds.length > 10 || message.embeds.some(card => !card || typeof card !== "object" || Array.isArray(card)))) throw Error("invalid_webhook_update");
  if (message.components !== undefined && (!Array.isArray(message.components) || message.components.length > 5 || message.components.some(row => !row || typeof row !== "object" || Array.isArray(row)))) throw Error("invalid_webhook_update");
  if (!Object.keys(message).length) throw Error("invalid_webhook_update");
  return { action: "update", ...message, ...(message.content !== undefined ? { content: message.content.slice(0, 2000) } : {}) };
}

function showModal(modal) {
  if (!modal || typeof modal !== "object" || Array.isArray(modal)
    || Object.keys(modal).some(key => !["title", "custom_id", "components"].includes(key))
    || typeof modal.title !== "string" || modal.title.length < 1 || modal.title.length > 45
    || typeof modal.custom_id !== "string" || modal.custom_id.length < 1 || modal.custom_id.length > 100
    || !Array.isArray(modal.components) || modal.components.length < 1 || modal.components.length > 5) throw Error("invalid_webhook_modal");
  return { type: "MODAL", data: modal };
}

function acknowledge() { return { action: "ack" }; }

function autocomplete(choices) {
  if (!Array.isArray(choices) || choices.length > 25) throw Error("invalid_autocomplete_choices");
  return { type: "APPLICATION_COMMAND_AUTOCOMPLETE_RESULT", data: { choices: choices.map(choice => {
    if (!choice || typeof choice !== "object" || Array.isArray(choice)
      || Object.keys(choice).some(key => !["name", "value"].includes(key)) || typeof choice.name !== "string"
      || !choice.name.trim() || [...choice.name].length > 100
      || (typeof choice.value !== "string" && typeof choice.value !== "number")
      || typeof choice.value === "string" && [...choice.value].length > 100
      || typeof choice.value === "number" && (!Number.isFinite(choice.value) || Math.abs(choice.value) > Number.MAX_SAFE_INTEGER)) throw Error("invalid_autocomplete_choices");
    return { name: choice.name, value: choice.value };
  }) } };
}

function selectedCommandOptions(event) {
  let options = event?.data?.options || [];
  for (let depth = 0; depth < 2; depth++) {
    if (!Array.isArray(options) || options.length > 25) throw Error("invalid_command_options");
    const branch = options.filter(item => [1, 2, "SUB_COMMAND", "SUB_COMMAND_GROUP"].includes(item?.type));
    if (!branch.length) return options;
    if (options.length !== 1 || !Array.isArray(branch[0].options)) throw Error("invalid_command_options");
    options = branch[0].options;
  }
  if (!Array.isArray(options) || options.length > 25 || options.some(item => item.options !== undefined)) throw Error("invalid_command_options");
  return options;
}

function defer(options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options)
    || Object.keys(options).some(key => key !== "ephemeral")
    || (options.ephemeral !== undefined && typeof options.ephemeral !== "boolean")) throw Error("invalid_webhook_defer");
  return { type: "DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE", data: { ephemeral: options.ephemeral === true } };
}

async function completeDeferredReply(event, message, { apiBase, fetchImpl = globalThis.fetch } = {}) {
  const id = event?.id || event?.event_id;
  if (typeof id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)
    || (event?.id && event?.event_id && event.id !== event.event_id)
    || typeof event?.token !== "string" || !/^altara_interaction_[a-f0-9]{48}$/.test(event.token)
    || typeof apiBase !== "string" || typeof fetchImpl !== "function") throw Error("invalid_deferred_completion");
  let base;
  try { base = new URL(apiBase); } catch { throw Error("invalid_deferred_completion"); }
  if (base.protocol !== "https:" || base.username || base.password || base.search || base.hash) throw Error("invalid_deferred_completion");
  const response = reply(message);
  const body = JSON.stringify({ action: "complete_interaction", event_id: id, response,...nativeSource(event) });
  const headers = { "Content-Type": "application/json", Authorization: "Interaction " + event.token };
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 3000);
  try {
    for (let attempt = 0; attempt < 3; attempt++) {
      const result = await fetchImpl(base.href.replace(/\/$/, "") + "/altara-bot-respond", {
        method: "POST", redirect: "error", credentials: "omit", signal: controller.signal, headers, body,
      });
      const receipt = await result.json();
      // Only this explicit pre-acceptance response proves the defer transaction
      // is not open yet. Never automatically retry an uncertain network result.
      if (result.status === 409 && receipt?.error === "event_not_open" && attempt < 2 && !controller.signal.aborted) {
        await new Promise(resolve => setTimeout(resolve, 100 * (attempt + 1)));
        continue;
      }
      if (!result.ok || !receipt || receipt.ok !== true) throw Error("deferred_completion_failed");
      return receipt;
    }
    throw Error("deferred_completion_failed");
  } catch { throw Error("deferred_completion_failed"); }
  finally { clearTimeout(timer); }
}

function createWebhookApp({ signingSecret = "", expressImpl = require("express"), onInteraction } = {}) {
  if (onInteraction !== undefined && typeof onInteraction !== "function") throw Error("invalid_interaction_handler");
  const app = expressImpl();
  const secret = String(signingSecret || "").trim();
  app.use(expressImpl.json({ verify: rawBodySaver }));

  app.get("/", (req, res) => {
    res.type("text/plain").send("ALTARA advanced webhook bot is running.");
  });

  app.post("/altara/interactions", async (req, res, next) => {
    try {
    if (!verifyAltaraSignature(req, secret)) {
      return res.status(401).json({ error: "invalid_signature" });
    }
    if (!req.body || typeof req.body !== "object" || Array.isArray(req.body)) {
      return res.status(400).json({ error: "invalid_interaction" });
    }

    if (req.body.type === "PING") {
      return res.json({ type: "PONG", challenge: req.body.challenge });
    }

    if (!["APPLICATION_COMMAND", "APPLICATION_COMMAND_AUTOCOMPLETE", "MESSAGE_COMPONENT", "MODAL_SUBMIT"].includes(req.body.type)) {
      return res.status(400).json({ error: "unknown_interaction_type" });
    }
    if (onInteraction) {
      try {
        const response = await onInteraction(req.body, { reply, update, showModal, acknowledge, autocomplete, selectedCommandOptions, defer, completeDeferredReply, followUpReply, uploadInteractionAttachment });
        if (response !== undefined) return res.json(response);
      } catch { return res.status(500).json({ error: "interaction_handler_failed" }); }
    }
    if (req.body.type === "APPLICATION_COMMAND_AUTOCOMPLETE") return res.json(autocomplete([]));
    if (req.body.type !== "APPLICATION_COMMAND" || req.body.data?.type && ![1,"CHAT_INPUT"].includes(req.body.data.type)) return res.status(400).json({ error: "interaction_handler_not_configured" });

    const commandName = String(req.body.data?.name || "").toLowerCase();
    const options = selectedCommandOptions(req.body);
    const firstValue = options.find((option) => option && typeof option === "object" && "value" in option)?.value;

    if (commandName === "hello") {
      return res.json(reply("Hello from ALTARA!"));
    }

    if (commandName === "ping") {
      return res.json(reply("Pong. Connection test passed."));
    }

    if (commandName === "roll") {
      const result = rollDice(firstValue || "1d20");
      if (!result) return res.json(reply("Invalid dice format. Try d20, 1d20, or 2d6."));
      return res.json(reply(`Rolled ${result.dice}: ${result.rolls.join(" + ")} = ${result.total}`));
    }

    return res.status(400).json({ error: "unknown_command" });
    } catch (error) {
      // Express 4 does not consume rejected async route promises itself.
      if (typeof next === "function") return next(error);
      return res.status(500).json({ error: "internal_error" });
    }
  });

  app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    const status = error?.status === 413 ? 413 : error?.status === 400 ? 400 : 500;
    return res.status(status).json({ error: status === 413 ? "request_too_large" : status === 400 ? "invalid_request" : "internal_error" });
  });
  return app;
}

module.exports = { createWebhookApp, reply, update, showModal, acknowledge, autocomplete, selectedCommandOptions, defer, completeDeferredReply, followUpReply, uploadInteractionAttachment };

if (require.main === module) {
  require("dotenv/config");
  const port = Number(process.env.PORT || 3000);
  const app = createWebhookApp({ signingSecret: process.env.ALTARA_SIGNING_SECRET });
  app.listen(port, () => {
    console.log(`ALTARA advanced webhook bot listening on http://localhost:${port}`);
  });
}

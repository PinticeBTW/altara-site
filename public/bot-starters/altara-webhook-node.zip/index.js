const http = require('node:http');
const { createHash } = require('node:crypto');
const { loadShared, respondToInteraction, functionsBase } = require('./commands');
const { createWebhookApp, defer, completeDeferredReply } = loadShared('index.webhook.js');
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function createHttpsBot({ signingSecret, functionsUrl, expressImpl = require('express'), fetchImpl = globalThis.fetch, completionDelayMs = 400, onCompletionError = () => {} } = {}) {
  if (typeof signingSecret !== 'string' || !signingSecret.trim()) throw Error('signing_secret_required');
  if (typeof fetchImpl !== 'function' || typeof onCompletionError !== 'function' || !Number.isSafeInteger(completionDelayMs) || completionDelayMs < 0 || completionDelayMs > 2000) throw Error('invalid_starter_options');
  const apiBase = functionsBase(functionsUrl), jobs = new Map(), responseJobs = new WeakMap(), active = new Set(), stopAbort = new AbortController();
  const app = expressImpl();
  let server, starting, closing, stopped = false;
  app.use((req, res, next) => {
    const json = res.json.bind(res);
    res.json = value => {
      const job = req.body && responseJobs.get(req.body);
      if (job && res.statusCode === 200) res.once('finish', () => schedule(job));
      return json(value);
    };
    next();
  });
  app.use(createWebhookApp({ signingSecret, expressImpl, onInteraction: (event, helpers) => respondToInteraction(event, helpers, payload => {
    if (stopped || !uuid.test(payload.id || '') || (payload.event_id !== undefined && payload.event_id !== payload.id)
      || !/^altara_interaction_[a-f0-9]{48}$/.test(payload.token || '')) throw Error('invalid_deferred_event');
    for (const [id, entry] of jobs) if (entry.deadline <= Date.now() && entry.state !== 'running') { clearTimeout(entry.timer); entry.token = null; jobs.delete(id); }
    const fingerprint = createHash('sha256').update(JSON.stringify([payload.token, payload.bot_id, payload.server_id, payload.channel_id, payload.user?.id])).digest('hex');
    let job = jobs.get(payload.id);
    if (job && job.fingerprint !== fingerprint) throw Error('deferred_event_conflict');
    if (!job) {
      if (jobs.size >= 64) throw Error('deferred_capacity_exceeded');
      job = { id: payload.id, token: payload.token, fingerprint, deadline: Date.now() + 5 * 60 * 1000, state: 'waiting', timer: null };
      jobs.set(job.id, job);
    }
    responseJobs.set(payload, job);
    return defer({ ephemeral: true });
  }) }));

  function schedule(job) {
    if (stopped || job.state !== 'waiting') return;
    job.state = 'scheduled';
    job.timer = setTimeout(() => {
      job.timer = null;
      if (stopped) return;
      job.state = 'running';
      const task = completeDeferredReply({ id: job.id, token: job.token }, { content: 'O trabalho terminou. Esta conclusão continua privada.', ephemeral: true }, {
        apiBase, fetchImpl: (url, options) => fetchImpl(url, { ...options, signal: AbortSignal.any([options.signal, stopAbort.signal]) }),
      }).then(() => { job.state = 'completed'; }, () => {
        job.state = stopped ? 'cancelled' : 'failed';
        if (!stopped) {
          try {
            const observed = onCompletionError('deferred_completion_failed');
            if (observed && typeof observed.then === 'function') Promise.resolve(observed).catch(() => {});
          } catch (_) {}
        }
      }).finally(() => { job.token = null; active.delete(task); });
      active.add(task);
    }, completionDelayMs);
  }
  async function stop() {
    if (closing) return closing;
    stopped = true; stopAbort.abort();
    for (const job of jobs.values()) { clearTimeout(job.timer); job.timer = null; job.token = null; if (job.state !== 'running') job.state = 'cancelled'; }
    closing = (async () => {
      if (starting) await starting.catch(() => {});
      if (server?.listening) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
      await Promise.allSettled([...active]); jobs.clear();
      return { closed: !server?.listening };
    })();
    return closing;
  }
  return {
    app, stop,
    async start({ port = 3001, host = '0.0.0.0' } = {}) {
      if (server || stopped) throw Error('starter_already_started');
      if (!Number.isSafeInteger(port) || port < 0 || port > 65535 || typeof host !== 'string' || !host) throw Error('invalid_listen_options');
      server = http.createServer(app);
      starting = new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, host, () => { server.off('error', reject); resolve(); }); });
      await starting;
      if (stopped) throw Error('starter_stopped_during_start');
      return { port: server.address().port };
    },
  };
}

module.exports = { createHttpsBot };

if (require.main === module) {
  let bot;
  try {
    const port = process.env.PORT ? Number(process.env.PORT) : 3001;
    bot = createHttpsBot({ signingSecret: process.env.ALTARA_SIGNING_SECRET, functionsUrl: process.env.ALTARA_FUNCTIONS_URL,
      onCompletionError: () => console.error('[altara] deferred_completion_failed') });
    const stop = () => { void bot.stop().catch(() => { console.error('[altara] shutdown_failed'); process.exitCode = 1; }); };
    process.once('SIGINT', stop); process.once('SIGTERM', stop);
    void bot.start({ port }).then(() => console.log('ALTARA HTTPS bot is listening.')).catch(() => { console.error('[altara] startup_failed'); process.exitCode = 1; void bot.stop(); });
  } catch { console.error('[altara] invalid_configuration'); process.exitCode = 1; }
}

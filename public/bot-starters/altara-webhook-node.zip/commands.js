const fs = require('node:fs');
const path = require('node:path');

function loadShared(file) {
  if (!['index.webhook.js', 'altara-client.js'].includes(file)) throw Error('invalid_shared_module');
  const local = path.join(__dirname, file);
  let resolved = local;
  try { fs.lstatSync(local); }
  catch (error) {
    // Source checkouts use the canonical sibling. Archives contain this exact
    // helper locally. Never catch dependency failures from inside that helper.
    if (error.code !== 'ENOENT' || error.path !== local) throw error;
    resolved = path.join(__dirname, '../altara-ping-bot-node', file);
  }
  return require(resolved);
}

const definitions = Object.freeze([
  { name: 'ping', description: 'Testa a ligação HTTPS do bot' },
  { name: 'painel', description: 'Experimenta botões, menus e formulários HTTPS' },
  { name: 'privado', description: 'Mostra uma resposta que só tu podes ver' },
  { name: 'formulario', description: 'Abre um formulário privado' },
  { name: 'adiado', description: 'Conclui uma resposta privada depois da confirmação inicial' },
]);
const ids = Object.freeze({ privateButton: 'starter:private', formButton: 'starter:form', select: 'starter:choose', modal: 'starter:form-submit' });
const choices = Object.freeze({ chess: 'Xadrez', rpg: 'RPG', quiz: 'Quiz' });
const controls = [
  { type: 1, components: [{ type: 2, style: 1, label: 'Resposta privada', custom_id: ids.privateButton }, { type: 2, style: 2, label: 'Abrir formulário', custom_id: ids.formButton }] },
  { type: 1, components: [{ type: 3, custom_id: ids.select, placeholder: 'Escolhe um jogo', min_values: 1, max_values: 1, options: Object.entries(choices).map(([value, label]) => ({ label, value })) }] },
];
const modal = { title: 'O teu próximo jogo', custom_id: ids.modal, components: [
  { type: 1, components: [{ type: 4, style: 1, custom_id: 'nickname', label: 'Como te podemos chamar?', required: true, min_length: 1, max_length: 40 }] },
  { type: 1, components: [{ type: 4, style: 2, custom_id: 'game', label: 'O que te apetece jogar?', required: false, max_length: 300 }] },
] };

function respondToInteraction(event, helpers, deferReply) {
  const data = event.data;
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw Error('invalid_starter_interaction');
  if (event.type === 'APPLICATION_COMMAND') {
    if (data.name === 'ping') return helpers.reply('Pong! O bot recebeu o comando por HTTPS.');
    if (data.name === 'painel') return helpers.reply({ content: 'Experimenta um botão, escolhe um jogo ou abre o formulário.', components: controls });
    if (data.name === 'privado') return helpers.reply({ content: 'Esta resposta é privada. Só tu a podes ver.', ephemeral: true });
    if (data.name === 'formulario') return helpers.showModal(modal);
    if (data.name === 'adiado') return deferReply(event);
  } else if (event.type === 'MESSAGE_COMPONENT') {
    if (data.component_type === 2 && data.custom_id === ids.privateButton) return helpers.reply({ content: 'O botão chegou ao bot. Esta resposta é privada.', ephemeral: true });
    if (data.component_type === 2 && data.custom_id === ids.formButton) return helpers.showModal(modal);
    if (data.component_type === 3 && data.custom_id === ids.select && Array.isArray(data.values) && data.values.length === 1 && Object.hasOwn(choices, data.values[0])) {
      return helpers.reply({ content: `Escolheste ${choices[data.values[0]]}. O menu chegou ao bot.`, ephemeral: true });
    }
  } else if (event.type === 'MODAL_SUBMIT' && data.custom_id === ids.modal) {
    if (!data.fields || typeof data.fields !== 'object' || Array.isArray(data.fields)
      || Object.keys(data.fields).some(key => !['nickname', 'game'].includes(key))
      || typeof data.fields.nickname !== 'string' || data.fields.nickname.length < 1 || data.fields.nickname.length > 40
      || (data.fields.game !== undefined && (typeof data.fields.game !== 'string' || data.fields.game.length > 300))) throw Error('invalid_starter_form');
    // Submitted fields are acknowledged without being published or echoed.
    return helpers.reply({ content: 'Formulário recebido pelo bot. A confirmação é privada.', ephemeral: true });
  }
  throw Error('unsupported_starter_interaction');
}

function functionsBase(value) {
  let url;
  try { url = new URL(value); } catch { throw Error('invalid_functions_url'); }
  if (typeof value !== 'string' || url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) throw Error('invalid_functions_url');
  return url.href.replace(/\/$/, '');
}

module.exports = { loadShared, definitions, ids, respondToInteraction, functionsBase };

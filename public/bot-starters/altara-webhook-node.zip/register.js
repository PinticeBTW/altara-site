const { loadShared, definitions, functionsBase } = require('./commands');
const { AltaraClient } = loadShared('altara-client.js');

async function registerCommands({ token, functionsUrl, client } = {}) {
  if (!client) {
    if (typeof token !== 'string' || !token.trim()) throw Error('bot_token_required_for_registration');
    client = new AltaraClient({ token, functionsUrl: functionsBase(functionsUrl) });
  }
  for (const { name, ...metadata } of definitions) client.command(name, metadata, async () => {});
  // Explicit additive registration does not disable unrelated commands and
  // never starts an SDK polling connection alongside the HTTPS receiver.
  const result = await client.callFunction('altara-bot-sync-commands', { commands: definitions.map(({ name }) => client.commandDefinitions.get(name)), disable_missing: false });
  if (result?.ok !== true) throw Error('command_registration_failed');
  return { registered: definitions.length };
}

module.exports = { registerCommands };
if (require.main === module) {
  void registerCommands({ token: process.env.ALTARA_BOT_TOKEN, functionsUrl: process.env.ALTARA_FUNCTIONS_URL })
    .then(result => console.log(`ALTARA HTTPS commands registered: ${result.registered}.`))
    .catch(() => { console.error('[altara] command_registration_failed'); process.exitCode = 1; });
}

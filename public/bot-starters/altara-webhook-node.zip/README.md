# ALTARA HTTPS bot (JavaScript)

An optional signed HTTPS receiver, separate from Bot Token Connection polling. Use Node.js 22.12 or newer. No Discord token/library adapter is included.

## Install and configure

1. Extract the archive and run `npm ci`.
2. Copy `.env.example` to `.env` only if `.env` does not already exist. Preserve existing values when updating an existing file. Fill `ALTARA_SIGNING_SECRET` with this application's signing key. For hosted ALTARA, copy the public `DEFAULT_FUNCTIONS_URL` at the top of the included `altara-client.js` into `ALTARA_FUNCTIONS_URL`; for another deployment, use its Functions URL. The URL must be set explicitly. Keep the signing key on your server. `PORT` defaults to 3001.
3. Run `npm start`. Expose `/altara/interactions` through your own valid HTTPS host or reverse proxy. This starter does not create hosting or a tunnel.
4. In the Developer Portal, verify that application's exact endpoint URL, then explicitly select HTTPS delivery. Bot Token Connection remains the platform default.
5. If these five commands are not registered, fill `ALTARA_BOT_TOKEN` in your server `.env` and run `npm run register` explicitly. Registration preserves other registered commands (`disable_missing:false`). It is not run by `npm start` and never starts a polling client. You can remove the token from the runtime environment afterwards.

The archive includes canonical `index.webhook.js` and `altara-client.js` helpers. Inside the repository, absent local helpers resolve to the canonical sibling example. Missing dependencies inside a helper remain errors.

## Commands

| Command | Result |
| --- | --- |
| `/ping` | Public connection reply |
| `/painel` | Public buttons and string select: private greeting, form and a fixed game choice |
| `/privado` | Author-only text reply |
| `/formulario` | Private form; its confirmation does not repeat submitted fields |
| `/adiado` | Private defer and one later private completion |

The menu accepts only Xadrez/RPG/Quiz. Controls do not edit their source message or require Manage Messages. Existing installation/channel/application-command grants remain required. The starter cannot grant itself permissions.

Raw-byte HMAC and timestamp verification come from the official webhook helper. Unsigned, modified or stale requests are rejected. Forms and callbacks are not logged. Private replies do not become public fallback messages if delivery fails.

Deferred replies use the signed event ID and its `Interaction` credential only in memory. Completion is scheduled after the initial HTTP response finishes. There is one completion per event; only an explicit `409/event_not_open` may retry within the official helper's bounded deadline. Unknown network acceptance is not automatically retried. At most 64 deferred event entries are retained for the five-minute event window; capacity errors fail safely. Completion errors emit a fixed code, never payloads or tokens.

Use Ctrl+C or SIGTERM to cancel completion timers, abort active completion requests and close this server's socket. Run the server only while you intend to receive callbacks; remote verification and automatic reconnect/hosting are operator responsibilities.

## Current limits

The existing five commands use initial replies/cards/public controls/forms and a single deferred initial slash completion. The canonical helper now prepares rich HTTPS results: private controls, upload IDs, explicit member mentions and fixed-visibility follow-ups. These additions require the matching backend/frontend package before hosted use; see the included SDK guide's **Rich HTTPS results** section. Uploads and follow-ups require stable request UUIDs and the original signed event capability. This example does not record microphone audio or connect to voice rooms.
